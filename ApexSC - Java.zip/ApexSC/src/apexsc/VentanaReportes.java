package apexsc;

import javax.swing.*;
import java.awt.*;

public class VentanaReportes extends JFrame {

    public VentanaReportes() {

        setTitle("Reportes del Sistema");
        setSize(500, 500); 
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        Color azul = new Color(0, 51, 102);
        Color dorado = new Color(218, 165, 32);
        Color fondo = new Color(245, 247, 255);
        Color azulClaro = new Color(230, 240, 255);

        // Panel principal con BorderLayout
        JPanel panelPrincipal = new JPanel(new BorderLayout(0, 20));
        panelPrincipal.setBackground(fondo);
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        //  TÍTULO 
        JLabel titulo = new JLabel("Reportes del Sistema", JLabel.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
        titulo.setForeground(azul);
        titulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Subtítulo
        JLabel subtitulo = new JLabel("Seleccione el tipo de reporte a generar", JLabel.CENTER);
        subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitulo.setForeground(new Color(100, 100, 100));
        subtitulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));

        // Panel para el título
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setBackground(fondo);
        panelTitulo.add(titulo, BorderLayout.CENTER);
        panelTitulo.add(subtitulo, BorderLayout.SOUTH);

        // BOTONES
        JPanel panelBotones = new JPanel(new GridLayout(0, 1, 12, 12)); // Más espacio entre botones
        panelBotones.setBackground(fondo);
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JButton btnCaja = crearBotonMejorado("Reporte de Caja", "Ver ingresos por cuotas, entradas y abonos", azul, dorado);
        JButton btnMorosidad = crearBotonMejorado("Reporte de Morosidad", "Consultar socios con cuotas pendientes", azul, dorado);
        JButton btnIngresos = crearBotonMejorado("Reporte de Ingresos", "Análisis detallado de todos los ingresos", azul, dorado);
        JButton btnAsistencia = crearBotonMejorado("Reporte de Asistencia", "Control de entradas utilizadas en eventos", azul, dorado);
        JButton btnExportarCSV = crearBotonMejorado("Exportar Datos", "Exportar reportes en formato CSV", azul, dorado);

        panelBotones.add(btnCaja);
        panelBotones.add(btnMorosidad);
        panelBotones.add(btnIngresos);
        panelBotones.add(btnAsistencia);
        panelBotones.add(btnExportarCSV);


        //  ENSAMBLADO 
        panelPrincipal.add(panelTitulo, BorderLayout.NORTH);
        panelPrincipal.add(panelBotones, BorderLayout.CENTER);
     

        add(panelPrincipal);

        //  ACCIONES 
        btnCaja.addActionListener(e -> {
            new VentanaReporteCaja();
            this.dispose(); // Cerrar esta ventana al abrir otra
        });
        
        btnMorosidad.addActionListener(e -> {
            new VentanaMorosos();
            this.dispose();
        });
        
        btnIngresos.addActionListener(e -> {
            new VentanaReporteIngresos();
            this.dispose();
        });
        
        btnAsistencia.addActionListener(e -> {
            new VentanaReporteAsistencia();
            this.dispose();
        });
        
        btnExportarCSV.addActionListener(e -> {
            new VentanaExportarReportes();
            this.dispose();
        });

        setVisible(true);
    }

    private JButton crearBotonMejorado(String texto, String tooltip, Color azul, Color dorado) {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 16));
        boton.setBackground(azul);
        boton.setForeground(Color.WHITE);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(dorado, 2),
            BorderFactory.createEmptyBorder(12, 20, 12, 20) 
        ));
        boton.setFocusPainted(false);
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setToolTipText(tooltip); // Tooltip descriptivo
        
                boton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                boton.setBackground(dorado);
                boton.setForeground(azul);
                boton.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(azul, 2),
                    BorderFactory.createEmptyBorder(12, 20, 12, 20)
                ));
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                boton.setBackground(azul);
                boton.setForeground(Color.WHITE);
                boton.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(dorado, 2),
                    BorderFactory.createEmptyBorder(12, 20, 12, 20)
                ));
            }
        });

        return boton;
    }

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaReportes());
    }
}