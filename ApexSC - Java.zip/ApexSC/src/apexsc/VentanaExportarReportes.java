package apexsc;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class VentanaExportarReportes extends JFrame {

    private final JCheckBox chkCaja;
    private final JCheckBox chkMorosos;
    private final JCheckBox chkIngresos;
    private final JCheckBox chkAsistencia;
    private final JCheckBox chkTodo;

    private final CuotaDAO cuotaDAO = new CuotaDAO();
    private final EntradaDAO entradaDAO = new EntradaDAO();
    private final AbonoPiletaDAO abonoDAO = new AbonoPiletaDAO();
    private final EventoDAO eventoDAO = new EventoDAO();

    public VentanaExportarReportes() {

        setTitle("Exportar Reportes (CSV)");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10,10));

        Color azul = new Color(0,51,102);
        Color dorado = new Color(218,165,32);
        Color fondo = new Color(245,247,255);

        JPanel panel = new JPanel(new GridLayout(0,1,10,10));
        panel.setBackground(fondo);
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));

        chkCaja      = new JCheckBox("Reporte de Caja");
        chkMorosos   = new JCheckBox("Reporte de Morosidad");
        chkIngresos  = new JCheckBox("Reporte de Ingresos");
        chkAsistencia= new JCheckBox("Reporte de Asistencia");
        chkTodo      = new JCheckBox("Seleccionar todo");

        chkCaja.setBackground(fondo);
        chkMorosos.setBackground(fondo);
        chkIngresos.setBackground(fondo);
        chkAsistencia.setBackground(fondo);
        chkTodo.setBackground(fondo);

        panel.add(chkCaja);
        panel.add(chkMorosos);
        panel.add(chkIngresos);
        panel.add(chkAsistencia);
        panel.add(chkTodo);

        chkTodo.addActionListener(e -> {
            boolean sel = chkTodo.isSelected();
            chkCaja.setSelected(sel);
            chkMorosos.setSelected(sel);
            chkIngresos.setSelected(sel);
            chkAsistencia.setSelected(sel);
        });

        JButton btnExportar = new JButton("Exportar CSV");
        btnExportar.setBackground(azul);
        btnExportar.setForeground(Color.WHITE);
        btnExportar.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnExportar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnExportar.setBorder(BorderFactory.createLineBorder(dorado,2));

        btnExportar.addActionListener(e -> exportar());

        add(panel, BorderLayout.CENTER);
        add(btnExportar, BorderLayout.SOUTH);

        setVisible(true);
    }

  
    // EXPORTACIÓN PRINCIPAL
  
    private void exportar() {
        if (!chkCaja.isSelected() && !chkMorosos.isSelected() &&
            !chkIngresos.isSelected() && !chkAsistencia.isSelected()) {

            JOptionPane.showMessageDialog(this,
                "Debe seleccionar al menos un reporte.");
            return;
        }

        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Seleccionar carpeta para exportar");
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File carpeta = fc.getSelectedFile();

        try {

            if (chkCaja.isSelected())       exportarCaja(carpeta);
            if (chkMorosos.isSelected())    exportarMorosos(carpeta);
            if (chkIngresos.isSelected())   exportarIngresos(carpeta);
            if (chkAsistencia.isSelected()) exportarAsistencia(carpeta);

            JOptionPane.showMessageDialog(this,
                    "Reportes generados correctamente en:\n" + carpeta.getAbsolutePath());

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error generando reportes: " + ex.getMessage());
        }
    }

 
    // REPORTE 1: CAJA (cuotas pagadas)

    private void exportarCaja(File carpeta) throws Exception {
        File archivo = new File(carpeta, "reporte_caja.csv");
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {

            pw.println("Socio,Periodo,Monto,Estado");

            List<Cuota> cuotas = cuotaDAO.listar();
            for (Cuota c : cuotas) {
                if (c.isPagada()) {
                    pw.println(
                            "\"" + c.getSocio().getNombre() + " " + c.getSocio().getApellido() + "\"," +
                            "\"" + c.getPeriodo() + "\"," +
                            c.getMonto() + "," +
                            "\"Pagada\""
                    );
                }
            }
        }
    }

 
    // REPORTE 2: MOROSIDAD
    
    private void exportarMorosos(File carpeta) throws Exception {
        File archivo = new File(carpeta, "reporte_morosidad.csv");
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {

            pw.println("Socio,DNI,Cuotas Pendientes,Total Deuda,Último Periodo");

            // CORRECCIÓN: Usar método listarMorosos sin parámetro o con string vacío
            List<MorosoDTO> lista = cuotaDAO.listarMorosos("");

            for (MorosoDTO m : lista) {
                // CORRECCIÓN: Usar getNombreCompleto() en lugar de getSocio()
                pw.println(
                        "\"" + m.getNombreCompleto() + "\"," +
                        "\"" + m.getDni() + "\"," +
                        m.getCuotasPendientes() + "," +
                        m.getTotalDeuda() + "," +
                        "\"" + m.getUltimoPeriodo() + "\""
                );
            }
        }
    }


    // REPORTE 3: INGRESOS (cuotas + entradas + abonos)

    private void exportarIngresos(File carpeta) throws Exception {
        File archivo = new File(carpeta, "reporte_ingresos.csv");
        DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {

            pw.println("Tipo,Fecha,Monto,Detalle");

            // Cuotas pagadas
            List<Cuota> cuotas = cuotaDAO.listar();
            for (Cuota c : cuotas) {
                if (c.isPagada()) {
                    pw.println("\"Cuota\"," + 
                            "\"" + c.getPeriodo() + "\"," + 
                            c.getMonto() + "," +
                            "\"Cuota de " + c.getSocio().getNombre() + " " + c.getSocio().getApellido() + "\""
                    );
                }
            }

            // Entradas vendidas
            List<Entrada> entradas = entradaDAO.listar();
            for (Entrada e : entradas) {
            
                String nombreEvento = "Evento #" + e.getIdEvento();
                try {
                    Evento evento = eventoDAO.buscarPorId(e.getIdEvento());
                    if (evento != null) {
                        nombreEvento = evento.getNombre();
                    }
                } catch (Exception ex) {
                    // Si hay error, mantener el nombre por defecto
                }
                
                pw.println("\"Entrada\"," + 
                        "\"" + e.getFechaCompra().format(f) + "\"," + 
                        e.getPrecio() + "," +
                        "\"Entrada " + e.getTipo() + " - " + nombreEvento + "\""
                );
            }

            // Abonos pagados
            List<AbonoPileta> abonos = abonoDAO.listar();
            for (AbonoPileta a : abonos) {
                if ("Pagado".equalsIgnoreCase(a.getEstadoPago())) {
                    pw.println("\"Abono\"," + 
                            "\"" + a.getFechaInicio() + "\"," + 
                            a.getPrecio() + "," +
                            "\"Abono pileta " + a.getTipo() + " - " + a.getSocio().getNombre() + " " + a.getSocio().getApellido() + "\""
                    );
                }
            }
        }
    }

    
    // REPORTE 4: ASISTENCIA (entradas usadas)

    private void exportarAsistencia(File carpeta) throws Exception {
        File archivo = new File(carpeta, "reporte_asistencia.csv");
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {

            pw.println("ID Entrada,Evento,Nombre Comprador,DNI,Usada");

            List<Entrada> entradas = entradaDAO.listar();
            for (Entrada e : entradas) {
                //Obtener nombre del evento
                String nombreEvento = "Evento #" + e.getIdEvento();
                try {
                    Evento evento = eventoDAO.buscarPorId(e.getIdEvento());
                    if (evento != null) {
                        nombreEvento = evento.getNombre();
                    }
                } catch (Exception ex) {
                    // Si hay error, mantener el nombre por defecto
                }
                
                pw.println(
                        e.getId() + "," +
                        "\"" + nombreEvento + "\"," +
                        "\"" + e.getNombreComprador() + "\"," +
                        "\"" + e.getDni() + "\"," +
                        (e.isUsado() ? "Sí" : "No")
                );
            }
        }
    }
}