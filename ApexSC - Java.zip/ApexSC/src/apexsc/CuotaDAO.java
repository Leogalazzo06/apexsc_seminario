package apexsc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CuotaDAO {

    // INSERTAR
    public void insertar(Cuota c) throws SQLException {
        String sql = "INSERT INTO cuota (periodo, monto, estado, pagada, id_socio) VALUES (?,?,?,?,?)";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, c.getPeriodo());
            ps.setDouble(2, c.getMonto());
            ps.setString(3, c.getEstado());
            ps.setBoolean(4, c.isPagada());
            ps.setInt(5, c.getSocio().getId());
            ps.executeUpdate();
        }
    }

    // LISTAR
    public List<Cuota> listar() throws SQLException {
        List<Cuota> lista = new ArrayList<>();

        String sql = """
            SELECT 
                c.id_cuota, c.periodo, c.monto, c.estado, c.pagada,
                s.id_socio, s.nombre, s.apellido, s.dni,
                s.estado AS estado_socio,
                s.id_usuario_creador,   -- CORRECTO
                s.categoria, s.periodicidad
            FROM cuota c
            JOIN socio s ON c.id_socio = s.id_socio
            ORDER BY c.id_cuota
        """;

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado_socio"),
                        rs.getInt("id_usuario_creador")   // CORRECTO
                );

                s.setCategoria(rs.getString("categoria"));
                s.setPeriodicidad(rs.getString("periodicidad"));

                Cuota c = new Cuota(
                        rs.getInt("id_cuota"),
                        rs.getString("periodo"),
                        rs.getDouble("monto"),
                        rs.getString("estado"),
                        s,
                        rs.getBoolean("pagada")
                );

                lista.add(c);
            }
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(Cuota c) throws SQLException {
        String sql = "UPDATE cuota SET periodo=?, monto=?, estado=?, pagada=?, id_socio=? WHERE id_cuota=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, c.getPeriodo());
            ps.setDouble(2, c.getMonto());
            ps.setString(3, c.getEstado());
            ps.setBoolean(4, c.isPagada());
            ps.setInt(5, c.getSocio().getId());
            ps.setInt(6, c.getId());
            ps.executeUpdate();
        }
    }

    // ELIMINAR
    public void eliminar(int idCuota) throws SQLException {
        String sql = "DELETE FROM cuota WHERE id_cuota=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCuota);
            ps.executeUpdate();
        }
    }

    // BUSCAR
    public List<Cuota> buscar(String texto) throws SQLException {
        List<Cuota> lista = new ArrayList<>();

        String sql = """
            SELECT 
                c.id_cuota, c.periodo, c.monto, c.estado, c.pagada,
                s.id_socio, s.nombre, s.apellido, s.dni,
                s.estado AS estado_socio,
                s.id_usuario_creador,   -- CORRECTO
                s.categoria, s.periodicidad
            FROM cuota c
            JOIN socio s ON c.id_socio = s.id_socio
            WHERE LOWER(s.nombre) LIKE ?
               OR LOWER(s.apellido) LIKE ?
               OR s.dni LIKE ?
               OR LOWER(c.estado) LIKE ?
            ORDER BY c.id_cuota
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String like = "%" + texto.toLowerCase() + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, "%" + texto + "%");
            ps.setString(4, like);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado_socio"),
                        rs.getInt("id_usuario_creador")   // CORRECTO
                );

                s.setCategoria(rs.getString("categoria"));
                s.setPeriodicidad(rs.getString("periodicidad"));

                Cuota c = new Cuota(
                        rs.getInt("id_cuota"),
                        rs.getString("periodo"),
                        rs.getDouble("monto"),
                        rs.getString("estado"),
                        s,
                        rs.getBoolean("pagada")
                );

                lista.add(c);
            }
        }
        return lista;
    }

    // DUPLICADO
    public boolean existeCuotaParaSocioYPeriodo(int idSocio, String periodo) throws SQLException {
        String sql = "SELECT COUNT(*) FROM cuota WHERE id_socio = ? AND periodo = ?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idSocio);
            ps.setString(2, periodo);

            ResultSet rs = ps.executeQuery();

            return rs.next() && rs.getInt(1) > 0;
        }
    }

    // MOROSOS
    public List<MorosoDTO> listarMorosos(String filtro) throws SQLException {

        List<MorosoDTO> lista = new ArrayList<>();

        String sql = """
            SELECT 
                s.nombre || ' ' || s.apellido AS socio,
                s.dni,
                COUNT(*) AS cuotas_pendientes,
                SUM(c.monto) AS total_deuda,
                MAX(c.periodo) AS ultimo_periodo
            FROM cuota c
            JOIN socio s ON c.id_socio = s.id_socio
            WHERE c.pagada = false
              AND LOWER(s.nombre || ' ' || s.apellido || ' ' || s.dni) LIKE ?
            GROUP BY s.nombre, s.apellido, s.dni
            ORDER BY cuotas_pendientes DESC
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + filtro.toLowerCase() + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new MorosoDTO(
                        rs.getString("socio"),
                        rs.getString("dni"),
                        rs.getInt("cuotas_pendientes"),
                        rs.getDouble("total_deuda"),
                        rs.getString("ultimo_periodo")
                ));
            }
        }

        return lista;
    }
}
