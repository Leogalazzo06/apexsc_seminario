package apexsc;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class VentanaCarnetSocio extends JFrame {

    private final Socio socio;

    public VentanaCarnetSocio(Socio socio) {
        this.socio = socio;

        setTitle("Carnet Digital - " + socio.getNombre());
        setSize(500, 330);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout());

        CarnetPanel panelCarnet = new CarnetPanel();
        add(panelCarnet, BorderLayout.CENTER);

        JButton btnGuardar = new JButton("💾 Guardar Carnet");
        btnGuardar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnGuardar.setBackground(new Color(0, 80, 180));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.setFocusPainted(false);
        btnGuardar.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnGuardar.addActionListener(e -> guardarCarnet(panelCarnet));

        JPanel footer = new JPanel();
        footer.add(btnGuardar);
        add(footer, BorderLayout.SOUTH);

        setVisible(true);
    }


    // PANEL 

    private class CarnetPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Fondo degradado
            GradientPaint gp = new GradientPaint(
                    0, 0, new Color(0, 60, 130),
                    getWidth(), getHeight(), new Color(25, 90, 160)
            );
            g2.setPaint(gp);
            g2.fillRoundRect(20, 20, 440, 230, 25, 25);

            // Sombra dentro del carnet
            g2.setColor(new Color(255, 255, 255, 40));
            g2.fillRoundRect(25, 25, 430, 220, 25, 25);

            // Título
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Segoe UI", Font.BOLD, 24));
            g2.drawString("Apex Sport Club", 140, 60);

            // Foto circular
            if (socio.getFotoRuta() != null) {
                try {
                    Image img = ImageIO.read(new File(socio.getFotoRuta()));
                    Image scaled = img.getScaledInstance(120, 120, Image.SCALE_SMOOTH);

                    BufferedImage mask = new BufferedImage(120, 120, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D gmask = mask.createGraphics();
                    gmask.setClip(new Ellipse2D.Float(0, 0, 120, 120));
                    gmask.drawImage(scaled, 0, 0, null);
                    gmask.dispose();

                    g2.drawImage(mask, 40, 95, null);
                } catch (Exception ignored) {}
            }

            // Datos del socio
            g2.setFont(new Font("Segoe UI", Font.PLAIN, 15));
            g2.drawString("Nombre: " + socio.getNombre(), 190, 105);
            g2.drawString("Apellido: " + socio.getApellido(), 190, 130);
            g2.drawString("DNI: " + socio.getDni(), 190, 155);
            g2.drawString("Categoría: " + socio.getCategoria(), 190, 180);
            g2.drawString("Estado: " + socio.getEstado(), 190, 205);

            // QR
            try {
                String contenido =
                        "ID=" + socio.getId() + "\n" +
                        "DNI=" + socio.getDni() + "\n" +
                        socio.getNombre() + " " + socio.getApellido();

                BufferedImage qr = QRGenerator.generarQR(contenido, 110, 110);


                g2.drawImage(qr, 360, 120, null);

            } catch (Exception e) {
                g2.drawString("QR Error", 360, 160);
            }
        }
    }

 
    // GUARDAR EN src/fotos_carnet/Nombre_Apellido.png
 
    private void guardarCarnet(JPanel panel) {
        try {
            BufferedImage img = new BufferedImage(
                    panel.getWidth(),
                    panel.getHeight(),
                    BufferedImage.TYPE_INT_RGB
            );

            Graphics2D g2 = img.createGraphics();
            panel.paint(g2);
            g2.dispose();

            // Carpeta donde se guardarán
            File carpeta = new File("src/fotos_carnet");

            if (!carpeta.exists()) carpeta.mkdirs();

            String nombreArchivo = socio.getNombre().replace(" ", "_") +
                    "_" +
                    socio.getApellido().replace(" ", "_") +
                    ".png";

            File archivo = new File(carpeta, nombreArchivo);

            ImageIO.write(img, "png", archivo);

            JOptionPane.showMessageDialog(this,
                    "Carnet guardado en:\n" + archivo.getAbsolutePath(),
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar carnet:\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
