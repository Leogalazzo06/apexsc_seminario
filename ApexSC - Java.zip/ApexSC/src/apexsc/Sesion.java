package apexsc;

public class Sesion {
    private static Usuario usuarioActual;

    // Establecer el usuario actual
    public static void setUsuarioActual(Usuario usuario) {
        usuarioActual = usuario;
    }

    // Obtener el usuario actual
    public static Usuario getUsuarioActual() {
        return usuarioActual;
    }

    // Verificar si hay un usuario logueado
    public static boolean hayUsuarioLogueado() {
        return usuarioActual != null;
    }

    // Cerrar sesión
    public static void cerrarSesion() {
        usuarioActual = null;
    }

    // Obtener ID del usuario actual (método que necesitas)
    public static int getIdUsuarioActual() {
        if (usuarioActual != null) {
            return usuarioActual.getId();
        }
        return -1; // o lanzar una excepción
    }
}
