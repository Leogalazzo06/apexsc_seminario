package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;

public class VentanaCuotas extends JFrame {

    private final JComboBox<Socio> cbSocio;
    private final JTextField txtMonto, txtBuscar;
    private final JComboBox<Integer> cbDia, cbMes, cbAnio;
    private final DefaultTableModel modeloTabla;
    private final JTable tablaCuotas;

    private final CuotaDAO cuotaDAO;
    private final SocioDAO socioDAO;

    private List<Cuota> listaCuotas = new ArrayList<>();
    private int idCuotaSeleccionada = -1;

    public VentanaCuotas() {
        setTitle("Gestión de Cuotas");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        Color azul = new Color(0, 51, 102);
        Color dorado = new Color(218, 165, 32);
        Color fondo = new Color(245, 247, 255);

        cuotaDAO = new CuotaDAO();
        socioDAO = new SocioDAO();

        //  Panel superior: formulario 
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(fondo);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(fondo);
        form.setBorder(BorderFactory.createTitledBorder("Registrar / Editar Cuota"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        cbSocio = new JComboBox<>();
        txtMonto = new JTextField(10);

        // combos fecha
        cbDia = new JComboBox<>();
        for (int i = 1; i <= 31; i++) cbDia.addItem(i);

        cbMes = new JComboBox<>();
        for (int i = 1; i <= 12; i++) cbMes.addItem(i);

        cbAnio = new JComboBox<>();
        int anioActual = LocalDate.now().getYear();
        for (int i = anioActual; i <= anioActual + 5; i++) cbAnio.addItem(i);

        // Fila 1
        gbc.gridx = 0; gbc.gridy = 0; form.add(new JLabel("Socio:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3; form.add(cbSocio, gbc);
        gbc.gridwidth = 1;

        // Fila 2
        gbc.gridx = 0; gbc.gridy = 1; form.add(new JLabel("Monto (automático):"), gbc);
        gbc.gridx = 1; form.add(txtMonto, gbc);
        txtMonto.setEditable(false); // se calcula según categoría

        gbc.gridx = 2; form.add(new JLabel("Fecha Vencimiento:"), gbc);
        JPanel panelFecha = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panelFecha.setBackground(fondo);
        panelFecha.add(cbDia);
        panelFecha.add(cbMes);
        panelFecha.add(cbAnio);
        gbc.gridx = 3; form.add(panelFecha, gbc);

        // Botones
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        botones.setBackground(fondo);
        JButton btnAgregar = crearBoton("Agregar", azul, dorado);
        JButton btnActualizar = crearBoton("Actualizar", azul, dorado);
        JButton btnEliminar = crearBoton("Eliminar", azul, dorado);
        JButton btnPagar = crearBoton("Marcar como Pagada", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);

        botones.add(btnAgregar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnPagar);
        botones.add(btnLimpiar);

        top.add(form, BorderLayout.CENTER);
        top.add(botones, BorderLayout.SOUTH);

        //  Panel central: búsqueda + tabla 
        JPanel center = new JPanel(new BorderLayout(0, 8));
        center.setBackground(fondo);
        center.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        busqueda.setBackground(fondo);
        busqueda.add(new JLabel("Buscar cuota (socio / estado):"));
        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);

        String[] columnas = {"ID", "Socio", "Periodo", "Monto", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaCuotas = new JTable(modeloTabla);
        tablaCuotas.setFillsViewportHeight(true);
        JScrollPane scroll = new JScrollPane(tablaCuotas);
        scroll.setBorder(BorderFactory.createTitledBorder("Listado de Cuotas"));

        center.add(busqueda, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        // Eventos
        btnAgregar.addActionListener(e -> agregarCuota());
        btnActualizar.addActionListener(e -> actualizarCuota());
        btnEliminar.addActionListener(e -> eliminarCuota());
        btnPagar.addActionListener(e -> marcarComoPagada());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnBuscar.addActionListener(e -> buscarCuota());
        tablaCuotas.getSelectionModel().addListSelectionListener(e -> cargarSeleccion());

        cbSocio.addActionListener(e -> actualizarMontoSugerido());

        // Cargar datos
        cargarSocios();
        cargarCuotasBD();

        setVisible(true);
    }

    private JButton crearBoton(String texto, Color fondo, Color borde) {
        JButton b = new JButton(texto);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(borde, 2));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    //  Carga inicial 

    private void cargarSocios() {
        try {
            cbSocio.removeAllItems();
            for (Socio s : socioDAO.listar()) {
                cbSocio.addItem(s);
            }
            actualizarMontoSugerido();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar socios:\n" + ex.getMessage());
        }
    }

    private void cargarCuotasBD() {
        try {
            listaCuotas = cuotaDAO.listar();
            actualizarTabla(listaCuotas);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al cargar cuotas:\n" + ex.getMessage());
        }
    }

    // --- Cálculo automático del monto según categoría ---
    private void actualizarMontoSugerido() {
        Socio socio = (Socio) cbSocio.getSelectedItem();
        if (socio == null) {
            txtMonto.setText("");
            return;
        }
        double monto = calcularMontoSegunCategoria(socio);
        txtMonto.setText(String.valueOf(monto));
    }

 private double calcularMontoSegunCategoria(Socio socio) {
    String cat = socio.getCategoria() != null ? socio.getCategoria() : "Adulto";
    double base;

    switch (cat) {
        case "Menor":
            base = 10000.0;
            break;
        case "Adulto":
            base = 15000.0;
            break;
        case "Familiar":
            base = 20000.0;
            break;
        case "Jubilado":
            base = 12000.0;
            break;
        case "Invitado":
            base = 20000.0;
            break;
        default:
            base = 15000.0; // Valor por defecto
    }

    // Bonificaciones
    if ("Familiar".equalsIgnoreCase(cat)) {
        base = base * 0.90;  // 10% descuento
    } 
    else if ("Jubilado".equalsIgnoreCase(cat)) {
        base = base * 0.80;  // 20% descuento
    }

    return base;
}

    //  CRUD 

    private void agregarCuota() {
        try {
            Socio socio = (Socio) cbSocio.getSelectedItem();
            if (socio == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un socio.");
                return;
            }

            LocalDate fecha = LocalDate.of(
                    (Integer) cbAnio.getSelectedItem(),
                    (Integer) cbMes.getSelectedItem(),
                    (Integer) cbDia.getSelectedItem()
            );

            String periodo = fecha.toString();

            // 🧱 RF-02: evitar duplicados para mismo socio + mismo período
            if (cuotaExisteParaSocioYPeriodo(socio.getId(), periodo)) {
                JOptionPane.showMessageDialog(this,
                        "Ya existe una cuota para este socio y período (" + periodo + ").",
                        "Cuota duplicada",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            double monto = Double.parseDouble(txtMonto.getText().trim());

            Cuota c = new Cuota();
            c.setSocio(socio);
            c.setMonto(monto);
            c.setFechaVencimiento(fecha);
            c.setEstado("Pendiente");
            c.setPagada(false);

            cuotaDAO.insertar(c);
            cargarCuotasBD();
            limpiarCamposSoloInputs();
            JOptionPane.showMessageDialog(this, "Cuota registrada con éxito.");

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "El monto debe ser numérico.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al agregar cuota:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean cuotaExisteParaSocioYPeriodo(int idSocio, String periodo) {
        try {
            return cuotaDAO.existeCuotaParaSocioYPeriodo(idSocio, periodo);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo verificar si existe la cuota:\n" + e.getMessage(),
                    "Aviso",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }
    }

    private void cargarSeleccion() {
        int fila = tablaCuotas.getSelectedRow();
        if (fila < 0 || listaCuotas.isEmpty()) return;

        int idx = tablaCuotas.convertRowIndexToModel(fila);
        Cuota c = listaCuotas.get(idx);
        idCuotaSeleccionada = c.getId();

        // Set socio
        for (int i = 0; i < cbSocio.getItemCount(); i++) {
            if (cbSocio.getItemAt(i).getId() == c.getSocio().getId()) {
                cbSocio.setSelectedIndex(i);
                break;
            }
        }

        txtMonto.setText(String.valueOf(c.getMonto()));

        try {
            LocalDate fecha = c.getFechaVencimiento();
            cbDia.setSelectedItem(fecha.getDayOfMonth());
            cbMes.setSelectedItem(fecha.getMonthValue());
            cbAnio.setSelectedItem(fecha.getYear());
        } catch (Exception ignored) {}
    }

    private void actualizarCuota() {
        if (idCuotaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una cuota para actualizar.");
            return;
        }

        try {
            Socio socio = (Socio) cbSocio.getSelectedItem();
            if (socio == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un socio.");
                return;
            }

            double monto = Double.parseDouble(txtMonto.getText().trim());
            LocalDate fecha = LocalDate.of(
                    (Integer) cbAnio.getSelectedItem(),
                    (Integer) cbMes.getSelectedItem(),
                    (Integer) cbDia.getSelectedItem()
            );

            Cuota original = listaCuotas.stream()
                    .filter(x -> x.getId() == idCuotaSeleccionada)
                    .findFirst()
                    .orElse(null);

            Cuota c = new Cuota();
            c.setId(idCuotaSeleccionada);
            c.setSocio(socio);
            c.setMonto(monto);
            c.setFechaVencimiento(fecha);

            // Mantener estado previo
            c.setEstado(original != null ? original.getEstado() : "Pendiente");
            c.setPagada(original != null && original.isPagada());

            cuotaDAO.actualizar(c);
            cargarCuotasBD();
            limpiarCampos();
            JOptionPane.showMessageDialog(this, "Cuota actualizada correctamente.");

        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "El monto debe ser numérico.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al actualizar cuota:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarCuota() {
        if (idCuotaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una cuota para eliminar.");
            return;
        }

        try {
            cuotaDAO.eliminar(idCuotaSeleccionada);
            cargarCuotasBD();
            limpiarCampos();
            JOptionPane.showMessageDialog(this, "Cuota eliminada.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al eliminar cuota:\n" + ex.getMessage());
        }
    }

    // Marcar como pagada 
    private void marcarComoPagada() {
        if (idCuotaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una cuota para marcar como pagada.");
            return;
        }

        try {
            Cuota c = listaCuotas.stream()
                    .filter(x -> x.getId() == idCuotaSeleccionada)
                    .findFirst()
                    .orElse(null);

            if (c == null) return;

            c.setEstado("Pagada");
            c.setPagada(true);

            cuotaDAO.actualizar(c);
            cargarCuotasBD();

            JOptionPane.showMessageDialog(this, "Cuota marcada como pagada.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al marcar como pagada:\n" + ex.getMessage());
        }
    }

    // --- Búsqueda y tabla ---

    private void buscarCuota() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) {
            cargarCuotasBD();
            return;
        }

        try {
            listaCuotas = cuotaDAO.buscar(q);
            actualizarTabla(listaCuotas);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al buscar cuotas:\n" + ex.getMessage());
        }
    }

    private void actualizarTabla(List<Cuota> lista) {
        modeloTabla.setRowCount(0);
        for (Cuota c : lista) {
            String estadoMostrar;

            if (c.isPagada()) estadoMostrar = "Pagada";
            else if (c.estaVencida()) estadoMostrar = "Vencida";
            else estadoMostrar = "Pendiente";

            modeloTabla.addRow(new Object[]{
                    c.getId(),
                    c.getSocio(),
                    c.getPeriodo(),
                    c.getMonto(),
                    estadoMostrar
            });
        }
    }

    // Limpieza 

    private void limpiarCamposSoloInputs() {
        txtMonto.setText("");
        txtMonto.requestFocus();
    }

    private void limpiarCampos() {
        limpiarCamposSoloInputs();
        txtBuscar.setText("");
        idCuotaSeleccionada = -1;
    }
}
