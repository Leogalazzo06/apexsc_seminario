package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class VentanaReporteIngresos extends JFrame {

    private final CuotaDAO cuotaDAO;
    private final EntradaDAO entradaDAO;
    private final AbonoPiletaDAO abonoDAO;

    private final JLabel lblCuotas;
    private final JLabel lblEntradas;
    private final JLabel lblAbonos;
    private final JLabel lblTotal;

    public VentanaReporteIngresos() {

        setTitle("Reporte de Ingresos");
        setSize(900, 650);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        cuotaDAO = new CuotaDAO();
        entradaDAO = new EntradaDAO();
        abonoDAO = new AbonoPiletaDAO();

        JPanel header = new JPanel(new GridLayout(4, 1, 5, 5));
        header.setBorder(BorderFactory.createTitledBorder("Totales Generales"));
        header.setBackground(Color.WHITE);

        lblCuotas = new JLabel("Ingresos por Cuotas: $0.00");
        lblEntradas = new JLabel("Ingresos por Entradas: $0.00");
        lblAbonos = new JLabel("Ingresos por Abonos: $0.00");
        lblTotal = new JLabel("TOTAL GENERAL: $0.00");

        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTotal.setForeground(new Color(0, 90, 0));

        header.add(lblCuotas);
        header.add(lblEntradas);
        header.add(lblAbonos);
        header.add(lblTotal);

        add(header, BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();

        tabs.add("Cuotas", crearTablaCuotas());
        tabs.add("Entradas", crearTablaEntradas());
        tabs.add("Abonos", crearTablaAbonos());

        add(tabs, BorderLayout.CENTER);

        calcularTotales();

        setVisible(true);
    }

 
    // TABLA CUOTAS
  
    private JScrollPane crearTablaCuotas() {

        DefaultTableModel modelo = new DefaultTableModel(
                new String[]{"ID", "Socio", "Periodo", "Monto"}, 0
        );

        try {
            List<Cuota> cuotas = cuotaDAO.listar();

            for (Cuota c : cuotas) {
                if (c.isPagada()) { // SOLO INGRESOS reales
                    modelo.addRow(new Object[]{
                            c.getId(),
                            c.getSocio().getNombre() + " " + c.getSocio().getApellido(),
                            c.getPeriodo(),
                            c.getMonto()
                    });
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error cargando cuotas: " + e.getMessage());
        }

        JTable tabla = new JTable(modelo);
        return new JScrollPane(tabla);
    }

 
    // TABLA ENTRADAS
 
    private JScrollPane crearTablaEntradas() {

        DefaultTableModel modelo = new DefaultTableModel(
                new String[]{"ID", "Evento", "Comprador", "DNI", "Tipo", "Precio"}, 0
        );

        try {
            List<Entrada> entradas = entradaDAO.listar();

            for (Entrada e : entradas) {
                modelo.addRow(new Object[]{
                        e.getId(),
                        e.getIdEvento(),
                        e.getNombreComprador(),
                        e.getDni(),
                        e.getTipo(),
                        e.getPrecio()
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error cargando entradas: " + e.getMessage());
        }

        JTable tabla = new JTable(modelo);
        return new JScrollPane(tabla);
    }


    // TABLA ABONOS

    private JScrollPane crearTablaAbonos() {

        DefaultTableModel modelo = new DefaultTableModel(
                new String[]{"ID", "Socio", "Inicio", "Fin", "Precio", "Estado Pago"}, 0
        );

        try {
            List<AbonoPileta> lista = abonoDAO.listar();

            for (AbonoPileta a : lista) {
                if (a.getEstadoPago().equalsIgnoreCase("Pagado")) {
                    modelo.addRow(new Object[]{
                            a.getId(),
                            a.getSocio().getNombre() + " " + a.getSocio().getApellido(),
                            a.getFechaInicio(),
                            a.getFechaFin(),
                            a.getPrecio(),
                            a.getEstadoPago()
                    });
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error cargando abonos: " + e.getMessage());
        }

        JTable tabla = new JTable(modelo);
        return new JScrollPane(tabla);
    }

   
    // CALCULAR TOTALES

    private void calcularTotales() {

        double totalCuotas = 0;
        double totalEntradas = 0;
        double totalAbonos = 0;

        try {
            for (Cuota c : cuotaDAO.listar()) {
                if (c.isPagada()) totalCuotas += c.getMonto();
            }

            for (Entrada e : entradaDAO.listar()) {
                totalEntradas += e.getPrecio();
            }

            for (AbonoPileta a : abonoDAO.listar()) {
                if ("Pagado".equalsIgnoreCase(a.getEstadoPago()))
                    totalAbonos += a.getPrecio();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error calculando totales: " + e.getMessage());
        }

        double totalGeneral = totalCuotas + totalEntradas + totalAbonos;

        lblCuotas.setText("Ingresos por Cuotas: $" + totalCuotas);
        lblEntradas.setText("Ingresos por Entradas: $" + totalEntradas);
        lblAbonos.setText("Ingresos por Abonos: $" + totalAbonos);
        lblTotal.setText("TOTAL GENERAL: $" + totalGeneral);
    }
}
