package apexsc;

import java.time.LocalDate;

public class AbonoPileta {

    private int id;
    private Socio socio;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private double precio;
    private String estado;       // Vigente / Vencido
    private String estadoPago;   // Pagado / Pendiente
    private String tipo;         // INDIVIDUAL o FAMILIAR

    public AbonoPileta() {}

    // Constructor completo (cuando viene desde BD)
    public AbonoPileta(int id, Socio socio, LocalDate fechaInicio, LocalDate fechaFin,
                       double precio, String estado, String estadoPago, String tipo) {
        this.id = id;
        this.socio = socio;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.precio = precio;
        this.estado = estado;
        this.estadoPago = estadoPago;
        this.tipo = tipo;
    }

    // Constructor para insertar
    public AbonoPileta(Socio socio, LocalDate fechaInicio, LocalDate fechaFin, double precio) {
        this.socio = socio;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.precio = precio;
        this.estado = calcularEstado();
        this.estadoPago = "Pendiente";
        this.tipo = "INDIVIDUAL";  // Valor por defecto
    }

    // Constructor para insertar con tipo
    public AbonoPileta(Socio socio, LocalDate fechaInicio, LocalDate fechaFin, 
                       double precio, String tipo) {
        this.socio = socio;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.precio = precio;
        this.tipo = tipo;
        this.estado = calcularEstado();
        this.estadoPago = "Pendiente";
    }

    
    // Getters / Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Socio getSocio() { return socio; }
    public void setSocio(Socio socio) { this.socio = socio; }

    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    public LocalDate getFechaFin() { return fechaFin; }
    public void setFechaFin(LocalDate fechaFin) { this.fechaFin = fechaFin; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getEstadoPago() { return estadoPago; }
    public void setEstadoPago(String estadoPago) { this.estadoPago = estadoPago; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

  
    // Cálculo automático

    public String calcularEstado() {
        LocalDate hoy = LocalDate.now();
        if ((hoy.isAfter(fechaInicio) || hoy.isEqual(fechaInicio)) && hoy.isBefore(fechaFin)) {
            return "Vigente";
        }
        return "Vencido";
    }

    @Override
    public String toString() {
        return "AbonoPileta{" +
                "id=" + id +
                ", socio=" + socio +
                ", fechaInicio=" + fechaInicio +
                ", fechaFin=" + fechaFin +
                ", precio=" + precio +
                ", estado='" + estado + '\'' +
                ", estadoPago='" + estadoPago + '\'' +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}