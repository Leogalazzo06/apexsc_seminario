package apexsc;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.awt.*;
import java.awt.image.BufferedImage;

public class QRGenerator {

    public static BufferedImage generarQR(String texto, int ancho, int alto) throws WriterException {

        QRCodeWriter qrWriter = new QRCodeWriter();
        BitMatrix matrix = qrWriter.encode(texto, BarcodeFormat.QR_CODE, ancho, alto);

        BufferedImage imagen = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = imagen.createGraphics();

        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ancho, alto);

        g.setColor(Color.BLACK);

        for (int x = 0; x < ancho; x++) {
            for (int y = 0; y < alto; y++) {
                if (matrix.get(x, y)) {
                    g.fillRect(x, y, 1, 1);
                }
            }
        }

        g.dispose();
        return imagen;
    }
}
