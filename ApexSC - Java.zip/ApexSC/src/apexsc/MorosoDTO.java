package apexsc;

public class MorosoDTO {

    private String nombreCompleto;
    private String dni;
    private int cuotasPendientes;
    private double totalDeuda;
    private String ultimoPeriodo;

    public MorosoDTO(String nombreCompleto, String dni, int cuotasPendientes, double totalDeuda, String ultimoPeriodo) {
        this.nombreCompleto = nombreCompleto;
        this.dni = dni;
        this.cuotasPendientes = cuotasPendientes;
        this.totalDeuda = totalDeuda;
        this.ultimoPeriodo = ultimoPeriodo;
    }

    public String getNombreCompleto() { return nombreCompleto; }
    public String getDni() { return dni; }
    public int getCuotasPendientes() { return cuotasPendientes; }
    public double getTotalDeuda() { return totalDeuda; }
    public String getUltimoPeriodo() { return ultimoPeriodo; }
}
