package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.time.LocalDateTime;
import java.util.List;
import java.sql.SQLException;

public class VentanaEntradas extends JFrame {

    private final JComboBox<Evento> cbEvento;
    private final JTextField txtNombre, txtDni, txtBuscar;
    private final JComboBox<String> cbTipo;
    private final JTextField txtPrecio;
    private final JLabel lblQRPreview;

    private final JTable tabla;
    private final DefaultTableModel modelo;

    private final EntradaDAO entradaDAO;
    private final EventoDAO eventoDAO;

    private int idEntradaSeleccionada = -1;

    public VentanaEntradas() {

        setTitle("Venta de Entradas");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        entradaDAO = new EntradaDAO();
        eventoDAO = new EventoDAO();

        Color azul = new Color(0, 51, 102);
        Color dorado = new Color(218, 165, 32);
        Color fondo = new Color(245, 247, 255);

        // PANEL SUPERIOR
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(fondo);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(fondo);
        form.setBorder(BorderFactory.createTitledBorder("Registrar Entrada"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,10,5,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        cbEvento = new JComboBox<>();
        txtNombre = new JTextField(15);
        txtDni = new JTextField(12);
        cbTipo = new JComboBox<>(new String[]{"Popular", "General", "Palco"});
        txtPrecio = new JTextField(8);
        txtPrecio.setEditable(false);

        // Cargar eventos
        cargarEventos();

        // Fila 1
        gbc.gridx=0; gbc.gridy=0; form.add(new JLabel("Evento:"), gbc);
        gbc.gridx=1; gbc.gridwidth=3; form.add(cbEvento, gbc); gbc.gridwidth=1;

        // Fila 2
        gbc.gridx=0; gbc.gridy=1; form.add(new JLabel("Nombre:"), gbc);
        gbc.gridx=1; form.add(txtNombre, gbc);
        gbc.gridx=2; form.add(new JLabel("DNI:"), gbc);
        gbc.gridx=3; form.add(txtDni, gbc);

        // Fila 3
        gbc.gridx=0; gbc.gridy=2; form.add(new JLabel("Tipo:"), gbc);
        gbc.gridx=1; form.add(cbTipo, gbc);

        gbc.gridx=2; form.add(new JLabel("Precio:"), gbc);
        gbc.gridx=3; form.add(txtPrecio, gbc);

        // QR previa
        lblQRPreview = new JLabel("", JLabel.CENTER);
        lblQRPreview.setPreferredSize(new Dimension(140,140));
        lblQRPreview.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        lblQRPreview.setOpaque(true);
        lblQRPreview.setBackground(Color.WHITE);

        JPanel qrPanel = new JPanel(new BorderLayout());
        qrPanel.setBackground(fondo);
        qrPanel.add(new JLabel("QR generado:", JLabel.CENTER), BorderLayout.NORTH);
        qrPanel.add(lblQRPreview, BorderLayout.CENTER);

        // Botones
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER,20,5));
        botones.setBackground(fondo);

        JButton btnGenerar = crearBoton("Generar Entrada", azul, dorado);
        JButton btnUsar = crearBoton("Marcar como Usada", azul, dorado);
        JButton btnEliminar = crearBoton("Eliminar", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);

        botones.add(btnGenerar);
        botones.add(btnUsar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        top.add(form, BorderLayout.CENTER);
        top.add(qrPanel, BorderLayout.EAST);
        top.add(botones, BorderLayout.SOUTH);

        // PANEL CENTRAL (tabla)
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(fondo);

        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);

        JPanel buscador = new JPanel(new FlowLayout(FlowLayout.LEFT,10,5));
        buscador.setBackground(fondo);
        buscador.add(new JLabel("Buscar entrada:"));
        buscador.add(txtBuscar);
        buscador.add(btnBuscar);

        modelo = new DefaultTableModel(
                new String[]{"ID", "Evento", "Comprador", "DNI", "Tipo", "Precio", "QR", "Usado"},
                0
        );
        tabla = new JTable(modelo);
        tabla.getSelectionModel().addListSelectionListener(e -> cargarSeleccion());
        JScrollPane scroll = new JScrollPane(tabla);

        center.add(buscador, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        // EVENTOS
        cbTipo.addActionListener(e -> actualizarPrecio());
        cbEvento.addActionListener(e -> actualizarPrecio());

        btnGenerar.addActionListener(e -> generarEntrada());
        btnUsar.addActionListener(e -> marcarUsada());
        btnEliminar.addActionListener(e -> eliminarEntrada());
        btnLimpiar.addActionListener(e -> limpiar());
        btnBuscar.addActionListener(e -> buscar());

        cargarEntradas();

        setVisible(true);
    }

   
    // CARGA INICIAL
    

    private void cargarEventos() {
        try {
            cbEvento.removeAllItems();
            for (Evento e : eventoDAO.listar()) {
                cbEvento.addItem(e);
            }
            actualizarPrecio();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Error al cargar eventos: "+ex.getMessage());
        }
    }

    private void cargarEntradas() {
        try {
            modelo.setRowCount(0);
            for (Entrada e : entradaDAO.listar()) {

                Evento ev = eventoDAO.buscarPorId(e.getIdEvento());
                String nombreEvento = (ev != null) ? ev.getNombre() : "Evento eliminado";

                modelo.addRow(new Object[]{
                        e.getId(),
                        nombreEvento,
                        e.getNombreComprador(),
                        e.getDni(),
                        e.getTipo(),
                        e.getPrecio(),
                        e.getCodigoQR(),
                        e.isUsado() ? "Sí" : "No"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Error al cargar entradas: "+ex.getMessage());
        }
    }

 
    // PRECIO SEGÚN EVENTO Y TIPO


    private void actualizarPrecio() {
        Evento ev = (Evento) cbEvento.getSelectedItem();
        if (ev == null) {
            txtPrecio.setText("");
            return;
        }

        String tipo = (String) cbTipo.getSelectedItem();

        double precio = switch(tipo) {
            case "Popular" -> ev.getPrecioSocio();
            case "General" -> ev.getPrecioGeneral();
            case "Palco"   -> ev.getPrecioInvitado();
            default        -> ev.getPrecioGeneral();
        };

        txtPrecio.setText(String.valueOf(precio));
    }

    
    // GENERAR ENTRADA
   

    private void generarEntrada() {

        try {
            Evento e = (Evento) cbEvento.getSelectedItem();
            if (e == null) {
                JOptionPane.showMessageDialog(this, "Debe seleccionar un evento.");
                return;
            }

            String nombre = txtNombre.getText().trim();
            String dni = txtDni.getText().trim();
            String tipo = (String) cbTipo.getSelectedItem();
            double precio = Double.parseDouble(txtPrecio.getText());

            if (nombre.isEmpty() || dni.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete nombre y DNI.");
                return;
            }

            // Generar QR único
            String qr = java.util.UUID.randomUUID().toString();

            // Crear entrada
            Entrada ent = new Entrada(
                    0,
                    e.getId(),
                    nombre,
                    dni,
                    tipo,
                    precio,
                    qr,
                    false,
                    LocalDateTime.now()
            );

            entradaDAO.insertar(ent);

            // Mostrar QR
            BufferedImage qrImg = QRGenerator.generarQR(qr, 140, 140);
            lblQRPreview.setIcon(new ImageIcon(qrImg));

            cargarEntradas();

            JOptionPane.showMessageDialog(this, "Entrada generada correctamente.");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

  
    // MARCAR COMO USADA
 
    private void marcarUsada() {

        if (idEntradaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una entrada.");
            return;
        }

        try {
            entradaDAO.marcarUsada(idEntradaSeleccionada);
            cargarEntradas();
            JOptionPane.showMessageDialog(this, "Entrada marcada como usada.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }


    // ELIMINAR ENTRADA

    private void eliminarEntrada() {
        if (idEntradaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione una entrada para eliminar.");
            return;
        }

        int resp = JOptionPane.showConfirmDialog(this,
                "¿Eliminar entrada?", "Confirmación",
                JOptionPane.YES_NO_OPTION);

        if (resp != JOptionPane.YES_OPTION) return;

        try {
            entradaDAO.eliminar(idEntradaSeleccionada);
            cargarEntradas();
            JOptionPane.showMessageDialog(this, "Entrada eliminada correctamente.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error eliminando entrada: " + ex.getMessage());
        }
    }

  
    // CARGAR SELECCIÓN


    private void cargarSeleccion() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) return;

        idEntradaSeleccionada = (int) modelo.getValueAt(fila, 0);
    }

  
    // BUSCAR
    

    private void buscar() {
        String q = txtBuscar.getText().trim();

        if (q.isEmpty()) {
            cargarEntradas();
            return;
        }

        try {
            modelo.setRowCount(0);
            for (Entrada e : entradaDAO.buscar(q)) {

                Evento ev = eventoDAO.buscarPorId(e.getIdEvento());
                String nombreEvento = (ev != null) ? ev.getNombre() : "Evento eliminado";

                modelo.addRow(new Object[]{
                        e.getId(),
                        nombreEvento,
                        e.getNombreComprador(),
                        e.getDni(),
                        e.getTipo(),
                        e.getPrecio(),
                        e.getCodigoQR(),
                        e.isUsado() ? "Sí" : "No"
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error en búsqueda: " + ex.getMessage());
        }
    }


    // LIMPIAR


    private void limpiar() {
        txtNombre.setText("");
        txtDni.setText("");
        txtBuscar.setText("");
        idEntradaSeleccionada = -1;
        lblQRPreview.setIcon(null);
    }


    // BOTÓN DISEÑADO


    private JButton crearBoton(String texto, Color azul, Color dorado) {
        JButton b = new JButton(texto);
        b.setBackground(azul);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBorder(BorderFactory.createLineBorder(dorado,2));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b.setBackground(dorado);
                b.setForeground(azul);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b.setBackground(azul);
                b.setForeground(Color.WHITE);
            }
        });

        return b;
    }
}
