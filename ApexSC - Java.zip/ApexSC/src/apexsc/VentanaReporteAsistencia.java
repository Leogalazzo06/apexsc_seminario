package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class VentanaReporteAsistencia extends JFrame {

    private final JComboBox<Evento> cbEvento;
    private final JLabel lblVendidas, lblUsadas, lblPorcentaje, lblAforo;
    private final JTable tabla;
    private final DefaultTableModel modelo;

    private final EventoDAO eventoDAO;
    private final EntradaDAO entradaDAO;

    public VentanaReporteAsistencia() {

        setTitle("Reporte de Asistencia a Eventos");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10,10));

        eventoDAO = new EventoDAO();
        entradaDAO = new EntradaDAO();

        Color fondo = new Color(245,247,255);
        Color azul = new Color(0,51,102);
        Color dorado = new Color(218,165,32);


        // PANEL SUPERIOR
       
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 20,10));
        top.setBackground(fondo);

        cbEvento = new JComboBox<>();
        cargarEventos();

        JButton btnGenerar = crearBoton("Generar Reporte", azul, dorado);

        top.add(new JLabel("Evento:"));
        top.add(cbEvento);
        top.add(btnGenerar);

        
        // PANEL DE DATOS 
  
        JPanel resumen = new JPanel(new GridLayout(2,2,10,10));
        resumen.setBackground(fondo);
        resumen.setBorder(BorderFactory.createTitledBorder("Resumen del Evento"));

        lblVendidas = new JLabel("Vendidas: 0");
        lblUsadas = new JLabel("Asistentes: 0");
        lblPorcentaje = new JLabel("Asistencia: 0%");
        lblAforo = new JLabel("Aforo: 0");

        lblVendidas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsadas.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPorcentaje.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblAforo.setFont(new Font("Segoe UI", Font.BOLD, 14));

        resumen.add(lblVendidas);
        resumen.add(lblUsadas);
        resumen.add(lblPorcentaje);
        resumen.add(lblAforo);

    
        // TABLA DETALLE
  
        modelo = new DefaultTableModel(
                new String[]{"Nombre", "DNI", "Tipo", "Precio", "QR", "Usada", "Fecha Compra"},
                0
        );

        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);

       
        // ARMADO GENERAL

        add(top, BorderLayout.NORTH);
        add(resumen, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);


        // EVENTOS

        btnGenerar.addActionListener(e -> generarReporte());

        setVisible(true);
    }

    private JButton crearBoton(String texto, Color azul, Color borde) {
        JButton b = new JButton(texto);
        b.setBackground(azul);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBorder(BorderFactory.createLineBorder(borde, 2));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void cargarEventos() {
        try {
            cbEvento.removeAllItems();
            for (Evento e : eventoDAO.listar()) {
                cbEvento.addItem(e);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error cargando eventos: "+e.getMessage());
        }
    }

    private void generarReporte() {

        Evento evento = (Evento) cbEvento.getSelectedItem();
        if (evento == null) {
            JOptionPane.showMessageDialog(this, "Seleccione un evento.");
            return;
        }

        try {
            List<Entrada> lista = entradaDAO.listarPorEvento(evento.getId());

            int vendidas = lista.size();
            int usadas = 0;

            modelo.setRowCount(0);

            for (Entrada en : lista) {
                if (en.isUsado()) usadas++;

                modelo.addRow(new Object[]{
                        en.getNombreComprador(),
                        en.getDni(),
                        en.getTipo(),
                        en.getPrecio(),
                        en.getCodigoQR(),
                        en.isUsado() ? "Sí" : "No",
                        en.getFechaCompra()
                });
            }

            lblVendidas.setText("Vendidas: " + vendidas);
            lblUsadas.setText("Asistentes: " + usadas);

            double porcentaje = vendidas == 0 ? 0 : (usadas * 100.0 / vendidas);
            lblPorcentaje.setText("Asistencia: " + String.format("%.1f", porcentaje) + "%");

            lblAforo.setText("Aforo: " + evento.getAforo());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error generando reporte: "+ex.getMessage());
        }
    }
}
