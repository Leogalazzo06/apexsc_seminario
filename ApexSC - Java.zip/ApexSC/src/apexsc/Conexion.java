package apexsc;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    private static final String URL = "jdbc:postgresql://localhost:5432/apex_sc";
    private static final String USER = "postgres";
    private static final String PASS = "45103729";

    public static Connection obtenerConexion() {
        Connection con = null;

        try {
            // Cargar driver
            Class.forName("org.postgresql.Driver");

            // Conectar
            con = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Conexión a PostgreSQL exitosa.");

        } catch (Exception e) {
            System.out.println("Error al conectar con PostgreSQL");
            e.printStackTrace();
        }

        return con;
    }
}
