package apexsc;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class EntradaDAO {

   
    // INSERTAR ENTRADA
    public void insertar(Entrada e) throws SQLException {

        String sql = """
            INSERT INTO entrada 
            (id_evento, nombre_comprador, dni, tipo, precio, codigo_qr, usado, fecha_compra)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, e.getIdEvento());
            ps.setString(2, e.getNombreComprador());
            ps.setString(3, e.getDni());
            ps.setString(4, e.getTipo());
            ps.setDouble(5, e.getPrecio());
            ps.setString(6, e.getCodigoQR());
            ps.setBoolean(7, e.isUsado());
            ps.setTimestamp(8, Timestamp.valueOf(e.getFechaCompra()));

            ps.executeUpdate();
        }
    }

   
    // LISTAR TODAS
  
    public List<Entrada> listar() throws SQLException {

        List<Entrada> lista = new ArrayList<>();

        String sql = "SELECT * FROM entrada ORDER BY id_entrada DESC";

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }

        return lista;
    }

 
    // BUSCAR (por nombre, dni o tipo)
    public List<Entrada> buscar(String texto) throws SQLException {

        List<Entrada> lista = new ArrayList<>();

        String sql = """
            SELECT * FROM entrada
            WHERE LOWER(nombre_comprador) LIKE ?
               OR dni LIKE ?
               OR LOWER(tipo) LIKE ?
            ORDER BY id_entrada DESC
            """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String like = "%" + texto.toLowerCase() + "%";

            ps.setString(1, like);
            ps.setString(2, "%" + texto + "%");
            ps.setString(3, like);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }

        return lista;
    }

  
    // LISTAR POR EVENTO
 
    public List<Entrada> listarPorEvento(int idEvento) throws SQLException {

        List<Entrada> lista = new ArrayList<>();

        String sql = "SELECT * FROM entrada WHERE id_evento = ? ORDER BY id_entrada DESC";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEvento);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }

        return lista;
    }


    // BUSCAR POR QR
    public Entrada buscarPorQR(String qr) throws SQLException {

        String sql = "SELECT * FROM entrada WHERE codigo_qr = ?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, qr);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapear(rs);
        }

        return null;
    }

 
    // EXISTE QR? (EVITAR DUPLICADOS)
  
    public boolean qrExiste(String qr) throws SQLException {

        String sql = "SELECT COUNT(*) FROM entrada WHERE codigo_qr = ?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, qr);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        }

        return false;
    }

   
    // MARCAR COMO USADA
 
    public void marcarUsada(int idEntrada) throws SQLException {

        String sql = "UPDATE entrada SET usado = true WHERE id_entrada = ?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEntrada);
            ps.executeUpdate();
        }
    }


    // ELIMINAR
  
    public void eliminar(int idEntrada) throws SQLException {

        String sql = "DELETE FROM entrada WHERE id_entrada = ?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEntrada);
            ps.executeUpdate();
        }
    }


    // MAPEO DE RESULTSET → OBJETO

    private Entrada mapear(ResultSet rs) throws SQLException {

        Entrada e = new Entrada();

        e.setId(rs.getInt("id_entrada"));
        e.setIdEvento(rs.getInt("id_evento"));
        e.setNombreComprador(rs.getString("nombre_comprador"));
        e.setDni(rs.getString("dni"));
        e.setTipo(rs.getString("tipo"));
        e.setPrecio(rs.getDouble("precio"));
        e.setCodigoQR(rs.getString("codigo_qr"));
        e.setUsado(rs.getBoolean("usado"));

        Timestamp ts = rs.getTimestamp("fecha_compra");
        e.setFechaCompra(ts != null ? ts.toLocalDateTime() : LocalDateTime.now());

        return e;
    }
}
