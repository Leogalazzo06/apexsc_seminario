package apexsc;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EventoDAO {

    // INSERTAR
    public void insertar(Evento e) throws SQLException {

        String sql = """
            INSERT INTO evento 
            (nombre, fecha_hora, aforo, lugar, precio_general, precio_socio, precio_invitado, id_usuario)
            VALUES (?,?,?,?,?,?,?,?)
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, e.getNombre());
            ps.setTimestamp(2, Timestamp.valueOf(e.getFecha().atStartOfDay()));
            ps.setInt(3, e.getAforo());
            ps.setString(4, e.getLugar());
            ps.setDouble(5, e.getPrecioGeneral());
            ps.setDouble(6, e.getPrecioSocio());
            ps.setDouble(7, e.getPrecioInvitado());
            ps.setInt(8, e.getIdUsuario());

            ps.executeUpdate();
        }
    }

    // LISTAR
    public List<Evento> listar() throws SQLException {

        List<Evento> lista = new ArrayList<>();

        String sql = """
            SELECT id_evento, nombre, fecha_hora, aforo, lugar,
                   precio_general, precio_socio, precio_invitado, id_usuario
            FROM evento
            ORDER BY fecha_hora DESC
        """;

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                LocalDate fecha = rs.getTimestamp("fecha_hora")
                        .toLocalDateTime().toLocalDate();

                Evento e = new Evento(
                        rs.getInt("id_evento"),
                        rs.getString("nombre"),
                        fecha,
                        rs.getInt("aforo"),
                        rs.getString("lugar"),
                        rs.getDouble("precio_general"),
                        rs.getDouble("precio_socio"),
                        rs.getDouble("precio_invitado"),
                        rs.getInt("id_usuario")
                );

                lista.add(e);
            }
        }

        return lista;
    }

    // BUSCAR POR ID 
  public Evento buscarPorId(int id) throws SQLException {

    String sql = """
        SELECT id_evento, nombre, fecha_hora, aforo, lugar,
               precio_general, precio_socio, precio_invitado, id_usuario
        FROM evento
        WHERE id_evento = ?
    """;

    try (Connection con = Conexion.obtenerConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {

            LocalDate fecha = rs.getTimestamp("fecha_hora")
                    .toLocalDateTime().toLocalDate();

            return new Evento(
                    rs.getInt("id_evento"),
                    rs.getString("nombre"),
                    fecha,
                    rs.getInt("aforo"),
                    rs.getString("lugar"),
                    rs.getDouble("precio_general"),
                    rs.getDouble("precio_socio"),
                    rs.getDouble("precio_invitado"),
                    rs.getInt("id_usuario")
            );
        }
    }

    return null;
}


    // ACTUALIZAR
    public void actualizar(Evento e) throws SQLException {

        String sql = """
            UPDATE evento 
            SET nombre=?, fecha_hora=?, aforo=?, lugar=?,
                precio_general=?, precio_socio=?, precio_invitado=?
            WHERE id_evento=?
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, e.getNombre());
            ps.setTimestamp(2, Timestamp.valueOf(e.getFecha().atStartOfDay()));
            ps.setInt(3, e.getAforo());
            ps.setString(4, e.getLugar());
            ps.setDouble(5, e.getPrecioGeneral());
            ps.setDouble(6, e.getPrecioSocio());
            ps.setDouble(7, e.getPrecioInvitado());
            ps.setInt(8, e.getId());

            ps.executeUpdate();
        }
    }

    // ELIMINAR
    public void eliminar(int idEvento) throws SQLException {

        String sql = "DELETE FROM evento WHERE id_evento=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idEvento);
            ps.executeUpdate();
        }
    }

    // BUSCAR (NOMBRE, LUGAR O FECHA)
    public List<Evento> buscar(String texto) throws SQLException {

        List<Evento> lista = new ArrayList<>();

        String sql = """
            SELECT id_evento, nombre, fecha_hora, aforo, lugar,
                   precio_general, precio_socio, precio_invitado, id_usuario
            FROM evento
            WHERE LOWER(nombre) LIKE ?
               OR LOWER(lugar) LIKE ?
               OR CAST(fecha_hora AS TEXT) LIKE ?
            ORDER BY fecha_hora DESC
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String like = "%" + texto.toLowerCase() + "%";

            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                LocalDate fecha = rs.getTimestamp("fecha_hora")
                        .toLocalDateTime().toLocalDate();

                Evento e = new Evento(
                        rs.getInt("id_evento"),
                        rs.getString("nombre"),
                        fecha,
                        rs.getInt("aforo"),
                        rs.getString("lugar"),
                        rs.getDouble("precio_general"),
                        rs.getDouble("precio_socio"),
                        rs.getDouble("precio_invitado"),
                        rs.getInt("id_usuario")
                );

                lista.add(e);
            }
        }

        return lista;
    }
}
