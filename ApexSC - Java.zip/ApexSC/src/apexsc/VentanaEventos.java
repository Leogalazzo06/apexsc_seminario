package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.sql.SQLException;

public class VentanaEventos extends JFrame {

    private final JTextField txtNombre, txtLugar, txtCapacidad,
            txtPrecioGeneral, txtPrecioSocio, txtPrecioInvitado, txtBuscar;

    private final JComboBox<Integer> cbDia, cbMes, cbAnio;

    private final DefaultTableModel modeloTabla;
    private final JTable tablaEventos;

    private final EventoDAO eventoDAO;
    private List<Evento> listaEventos = new ArrayList<>();

    private int idEventoSeleccionado = -1;

    private final int idUsuarioLogueado;

    public VentanaEventos(int idUsuarioLogueado) {

        this.idUsuarioLogueado = idUsuarioLogueado;  // Guardamos quién registra eventos

        setTitle("Gestión de Eventos");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10, 10));

        Color azul = new Color(0, 51, 102);
        Color dorado = new Color(218, 165, 32);
        Color fondo = new Color(245, 247, 255);

        eventoDAO = new EventoDAO();

   
        // PANEL SUPERIOR (FORMULARIO)
  
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(fondo);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(fondo);
        form.setBorder(BorderFactory.createTitledBorder("Registrar / Editar Evento"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Inputs 
        txtNombre = new JTextField(16);
        txtLugar = new JTextField(16);
        txtCapacidad = new JTextField(8);
        txtPrecioGeneral = new JTextField(8);
        txtPrecioSocio = new JTextField(8);
        txtPrecioInvitado = new JTextField(8);

        // Combos fecha
        cbDia = new JComboBox<>();
        for (int i = 1; i <= 31; i++) cbDia.addItem(i);

        cbMes = new JComboBox<>();
        for (int i = 1; i <= 12; i++) cbMes.addItem(i);

        cbAnio = new JComboBox<>();
        int anioActual = LocalDate.now().getYear();
        for (int i = anioActual; i <= anioActual + 5; i++) cbAnio.addItem(i);

        // Fila 1: nombre y lugar
        gbc.gridx = 0; gbc.gridy = 0; form.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1; form.add(txtNombre, gbc);

        gbc.gridx = 2; form.add(new JLabel("Lugar:"), gbc);
        gbc.gridx = 3; form.add(txtLugar, gbc);

        //  Fila 2: fecha
        gbc.gridx = 0; gbc.gridy = 1; form.add(new JLabel("Fecha:"), gbc);

        JPanel fechaPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        fechaPanel.setBackground(fondo);
        fechaPanel.add(cbDia);
        fechaPanel.add(cbMes);
        fechaPanel.add(cbAnio);

        gbc.gridx = 1; gbc.gridwidth = 3;
        form.add(fechaPanel, gbc);
        gbc.gridwidth = 1;

        //  Fila 3: capacidad 
        gbc.gridx = 0; gbc.gridy = 2; form.add(new JLabel("Capacidad:"), gbc);
        gbc.gridx = 1; form.add(txtCapacidad, gbc);

        // Fila 4: precios 
        gbc.gridx = 0; gbc.gridy = 3; form.add(new JLabel("Precio General:"), gbc);
        gbc.gridx = 1; form.add(txtPrecioGeneral, gbc);

        gbc.gridx = 2; form.add(new JLabel("Precio Socio:"), gbc);
        gbc.gridx = 3; form.add(txtPrecioSocio, gbc);

        gbc.gridx = 0; gbc.gridy = 4; form.add(new JLabel("Precio Invitado:"), gbc);
        gbc.gridx = 1; form.add(txtPrecioInvitado, gbc);

        // Botones 
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        botones.setBackground(fondo);

        JButton btnAgregar = crearBoton("Agregar", azul, dorado);
        JButton btnActualizar = crearBoton("Actualizar", azul, dorado);
        JButton btnEliminar = crearBoton("Eliminar", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);

        botones.add(btnAgregar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        top.add(form, BorderLayout.CENTER);
        top.add(botones, BorderLayout.SOUTH);


        // PANEL CENTRAL (TABLA)
        
        JPanel center = new JPanel(new BorderLayout(0, 8));
        center.setBackground(fondo);
        center.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        busqueda.setBackground(fondo);
        busqueda.add(new JLabel("Buscar evento:"));

        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);

        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);

        String[] columnas = {
                "ID", "Nombre", "Fecha", "Lugar", "Capacidad",
                "General", "Socio", "Invitado"
        };

        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tablaEventos = new JTable(modeloTabla);
        tablaEventos.setFillsViewportHeight(true);
        tablaEventos.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(tablaEventos);
        scroll.setBorder(BorderFactory.createTitledBorder("Listado de Eventos"));

        center.add(busqueda, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

      
        // EVENTOS BOTONES
      
        btnAgregar.addActionListener(e -> agregarEvento());
        btnActualizar.addActionListener(e -> actualizarEvento());
        btnEliminar.addActionListener(e -> eliminarEvento());
        btnLimpiar.addActionListener(e -> limpiarCampos());
        btnBuscar.addActionListener(e -> buscarEvento());

        tablaEventos.getSelectionModel().addListSelectionListener(e -> cargarSeleccion());

        cargarEventosBD();
        setVisible(true);
    }

    private JButton crearBoton(String texto, Color fondo, Color borde) {
        JButton b = new JButton(texto);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(borde, 2));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

  
    // CARGA INICIAL
  
    private void cargarEventosBD() {
        try {
            listaEventos = eventoDAO.listar();
            actualizarTabla();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar eventos:\n" + ex.getMessage());
        }
    }

    private void actualizarTabla() {
        modeloTabla.setRowCount(0);

        for (Evento e : listaEventos) {
            modeloTabla.addRow(new Object[]{
                    e.getId(),
                    e.getNombre(),
                    e.getFecha(),
                    e.getLugar(),
                    e.getAforo(),
                    e.getPrecioGeneral(),
                    e.getPrecioSocio(),
                    e.getPrecioInvitado()
            });
        }
    }

  
    // CRUD

    private void agregarEvento() {
        try {
            String nombre = txtNombre.getText().trim();
            String lugar = txtLugar.getText().trim();

            if (nombre.isEmpty() || lugar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nombre y lugar son obligatorios.");
                return;
            }

            int aforo = Integer.parseInt(txtCapacidad.getText().trim());
            double general = Double.parseDouble(txtPrecioGeneral.getText().trim());
            double socio = Double.parseDouble(txtPrecioSocio.getText().trim());
            double invitado = Double.parseDouble(txtPrecioInvitado.getText().trim());

            LocalDate fecha = LocalDate.of(
                    (Integer) cbAnio.getSelectedItem(),
                    (Integer) cbMes.getSelectedItem(),
                    (Integer) cbDia.getSelectedItem()
            );

          
            // GUARDA EL USUARIO REAL
          
            Evento e = new Evento(
                    nombre, fecha, aforo, lugar,
                    general, socio, invitado,
                    idUsuarioLogueado
            );

            eventoDAO.insertar(e);
            cargarEventosBD();
            limpiarCamposSoloInputs();

            JOptionPane.showMessageDialog(this, "Evento registrado con éxito.");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al agregar evento:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarSeleccion() {
        int fila = tablaEventos.getSelectedRow();
        if (fila < 0 || listaEventos.isEmpty()) return;

        int idx = tablaEventos.convertRowIndexToModel(fila);
        Evento e = listaEventos.get(idx);
        idEventoSeleccionado = e.getId();

        txtNombre.setText(e.getNombre());
        txtLugar.setText(e.getLugar());
        txtCapacidad.setText(String.valueOf(e.getAforo()));

        txtPrecioGeneral.setText(String.valueOf(e.getPrecioGeneral()));
        txtPrecioSocio.setText(String.valueOf(e.getPrecioSocio()));
        txtPrecioInvitado.setText(String.valueOf(e.getPrecioInvitado()));

        LocalDate f = e.getFecha();
        cbDia.setSelectedItem(f.getDayOfMonth());
        cbMes.setSelectedItem(f.getMonthValue());
        cbAnio.setSelectedItem(f.getYear());
    }

    private void actualizarEvento() {
        if (idEventoSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un evento para actualizar.");
            return;
        }

        try {
            String nombre = txtNombre.getText().trim();
            String lugar = txtLugar.getText().trim();

            int aforo = Integer.parseInt(txtCapacidad.getText().trim());
            double general = Double.parseDouble(txtPrecioGeneral.getText().trim());
            double socio = Double.parseDouble(txtPrecioSocio.getText().trim());
            double invitado = Double.parseDouble(txtPrecioInvitado.getText().trim());

            LocalDate fecha = LocalDate.of(
                    (Integer) cbAnio.getSelectedItem(),
                    (Integer) cbMes.getSelectedItem(),
                    (Integer) cbDia.getSelectedItem()
            );

            Evento e = new Evento(
                    idEventoSeleccionado,
                    nombre,
                    fecha,
                    aforo,
                    lugar,
                    general,
                    socio,
                    invitado,
                    idUsuarioLogueado  // No se pierde usuario quien lo creó
            );

            eventoDAO.actualizar(e);
            cargarEventosBD();
            limpiarCampos();

            JOptionPane.showMessageDialog(this, "Evento actualizado correctamente.");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar evento:\n" + ex.getMessage());
        }
    }

    private void eliminarEvento() {
        if (idEventoSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un evento para eliminar.");
            return;
        }

        try {
            eventoDAO.eliminar(idEventoSeleccionado);
            cargarEventosBD();
            limpiarCampos();
            JOptionPane.showMessageDialog(this, "Evento eliminado.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al eliminar evento:\n" + ex.getMessage());
        }
    }


    // BUSCAR
    private void buscarEvento() {
        String q = txtBuscar.getText().trim();
        if (q.isEmpty()) {
            cargarEventosBD();
            return;
        }

        try {
            listaEventos = eventoDAO.buscar(q);
            actualizarTabla();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al buscar eventos:\n" + ex.getMessage());
        }
    }


    // LIMPIEZA

    private void limpiarCampos() {
        limpiarCamposSoloInputs();
        txtBuscar.setText("");
        idEventoSeleccionado = -1;
    }

    private void limpiarCamposSoloInputs() {
        txtNombre.setText("");
        txtLugar.setText("");
        txtCapacidad.setText("");
        txtPrecioGeneral.setText("");
        txtPrecioSocio.setText("");
        txtPrecioInvitado.setText("");

        txtNombre.requestFocus();
    }
}
