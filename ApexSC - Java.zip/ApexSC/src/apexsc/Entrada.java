package apexsc;

import java.time.LocalDateTime;

public class Entrada {

    private int id;
    private int idEvento;
    private String nombreComprador;
    private String dni;
    private String tipo;          // General / Socio / Invitado
    private double precio;
    private String codigoQR;      // QR único
    private boolean usado;        // true = ya escaneada
    private LocalDateTime fechaCompra;

    public Entrada() {}

    public Entrada(int id, int idEvento, String nombreComprador, String dni,
                   String tipo, double precio, String codigoQR,
                   boolean usado, LocalDateTime fechaCompra) {
        this.id = id;
        this.idEvento = idEvento;
        this.nombreComprador = nombreComprador;
        this.dni = dni;
        this.tipo = tipo;
        this.precio = precio;
        this.codigoQR = codigoQR;
        this.usado = usado;
        this.fechaCompra = fechaCompra;
    }

    public Entrada(int idEvento, String nombreComprador, String dni,
                   String tipo, double precio, String codigoQR) {
        this.idEvento = idEvento;
        this.nombreComprador = nombreComprador;
        this.dni = dni;
        this.tipo = tipo;
        this.precio = precio;
        this.codigoQR = codigoQR;
        this.usado = false;
        this.fechaCompra = LocalDateTime.now();
    }

    // Getters y Setters

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdEvento() { return idEvento; }
    public void setIdEvento(int idEvento) { this.idEvento = idEvento; }

    public String getNombreComprador() { return nombreComprador; }
    public void setNombreComprador(String nombreComprador) { this.nombreComprador = nombreComprador; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public String getCodigoQR() { return codigoQR; }
    public void setCodigoQR(String codigoQR) { this.codigoQR = codigoQR; }

    public boolean isUsado() { return usado; }
    public void setUsado(boolean usado) { this.usado = usado; }

    public LocalDateTime getFechaCompra() { return fechaCompra; }
    public void setFechaCompra(LocalDateTime fechaCompra) { this.fechaCompra = fechaCompra; }

    @Override
    public String toString() {
        return nombreComprador + " (" + dni + ") - " + tipo;
    }
}
