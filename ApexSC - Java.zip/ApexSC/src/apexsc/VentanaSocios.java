package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class VentanaSocios extends JFrame {

    //  Componentes principales 
    private final JTextField txtNombre, txtApellido, txtDni, txtBuscar;
    private final JComboBox<String> cbEstado;
    private final JComboBox<String> cbCategoria;
    private final DefaultTableModel modeloTabla;
    private final JTable tablaSocios;

    private final SocioDAO dao;
    private int idSeleccionado = -1;

    // Ruta de foto seleccionada
    private String rutaFotoActual = null;

    //  Constructor 
    public VentanaSocios() {
        setTitle("Gestión de Socios");
        setSize(950, 650);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        dao = new SocioDAO();

        // Colores corporativos
        Color azul = new Color(0, 51, 102);
        Color dorado = new Color(218, 165, 32);
        Color fondo = new Color(245, 247, 255);

        //  Panel superior: formulario 
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(fondo);
        top.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(fondo);
        form.setBorder(BorderFactory.createTitledBorder("Registrar / Editar Socio"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtNombre = new JTextField(14);
        txtApellido = new JTextField(14);
        txtDni = new JTextField(12);
        cbEstado = new JComboBox<>(new String[]{"Activo", "Inactivo"});
        cbCategoria = new JComboBox<>(new String[]{"Menor", "Adulto", "Familiar", "Jubilado", "Invitado"});

        // Fila 1: Nombre / Apellido
        gbc.gridx = 0; gbc.gridy = 0; form.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1; form.add(txtNombre, gbc);

        gbc.gridx = 2; form.add(new JLabel("Apellido:"), gbc);
        gbc.gridx = 3; form.add(txtApellido, gbc);

        // Fila 2: DNI / Estado
        gbc.gridx = 0; gbc.gridy = 1; form.add(new JLabel("DNI:"), gbc);
        gbc.gridx = 1; form.add(txtDni, gbc);

        gbc.gridx = 2; form.add(new JLabel("Estado:"), gbc);
        gbc.gridx = 3; form.add(cbEstado, gbc);

        // Fila 3: Categoría
        gbc.gridx = 0; gbc.gridy = 2; form.add(new JLabel("Categoría:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3; form.add(cbCategoria, gbc);
        gbc.gridwidth = 1;

        // Fila 4: BOTÓN CARGAR FOTO
        JButton btnCargarFoto = crearBoton("Cargar Foto", azul, dorado);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 4;
        form.add(btnCargarFoto, gbc);
        gbc.gridwidth = 1;

        //  Botones CRUD 
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        botones.setBackground(fondo);

        JButton btnAgregar = crearBoton("Agregar", azul, dorado);
        JButton btnActualizar = crearBoton(" Actualizar", azul, dorado);
        JButton btnEliminar = crearBoton(" Eliminar", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);
        JButton btnCarnet = crearBoton("Carnet Digital", azul, dorado);

        botones.add(btnAgregar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(btnCarnet);

        top.add(form, BorderLayout.CENTER);
        top.add(botones, BorderLayout.SOUTH);

        // Panel central: búsqueda y tabla 
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(fondo);
        center.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        busqueda.setBackground(fondo);

        busqueda.add(new JLabel("Buscar:"));
        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);

        modeloTabla = new DefaultTableModel(
                new String[]{"ID", "Nombre", "Apellido", "DNI", "Estado", "Categoría"},
                0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tablaSocios = new JTable(modeloTabla);
        tablaSocios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaSocios.getSelectionModel().addListSelectionListener(e -> cargarSeleccion());
        tablaSocios.setRowHeight(25);

        JScrollPane scroll = new JScrollPane(tablaSocios);
        scroll.setBorder(BorderFactory.createTitledBorder("Listado de Socios"));

        center.add(busqueda, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        // Eventos
        btnAgregar.addActionListener(e -> agregarSocio());
        btnActualizar.addActionListener(e -> actualizarSocio());
        btnEliminar.addActionListener(e -> eliminarSocio());
        btnLimpiar.addActionListener(e -> limpiar());
        btnBuscar.addActionListener(e -> buscar());
        btnCarnet.addActionListener(e -> abrirCarnet());

        btnCargarFoto.addActionListener(e -> seleccionarFoto());

        // Cargar BD
        cargarTablaBD();
        setVisible(true);
    }

    //  Crear botón estilizado
    private JButton crearBoton(String texto, Color fondo, Color borde) {
        JButton b = new JButton(texto);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(borde, 2));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    // Seleccionar foto del sistema
    private void seleccionarFoto() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Seleccionar foto del socio");

        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Imágenes JPG y PNG", "jpg", "jpeg", "png"
        ));

        int resultado = chooser.showOpenDialog(this);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            rutaFotoActual = chooser.getSelectedFile().getAbsolutePath();

            JOptionPane.showMessageDialog(this,
                    "Foto seleccionada:\n" + rutaFotoActual,
                    "Foto cargada",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    //  Abrir carnet digital
    private void abrirCarnet() {
        int fila = tablaSocios.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un socio para generar el carnet.",
                    "Selección requerida",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String dni = tablaSocios.getValueAt(fila, 3).toString();

        try {
            List<Socio> lista = dao.buscar(dni);
            if (lista.isEmpty()) return;

            Socio socio = lista.get(0);
            new VentanaCarnetSocio(socio);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al abrir carnet:\n" + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

  
    // CRUD

    private int obtenerIdUsuarioActual() {
        if (Sesion.hayUsuarioLogueado()) return Sesion.getIdUsuarioActual();
        return 1;
    }

    private void agregarSocio() {
        try {
            String nombre = txtNombre.getText().trim();
            String apellido = txtApellido.getText().trim();
            String dni = txtDni.getText().trim();
            String estado = cbEstado.getSelectedItem().toString();
            String categoria = cbCategoria.getSelectedItem().toString();

            if (nombre.isEmpty() || apellido.isEmpty() || dni.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Complete todos los campos obligatorios.",
                        "Campos incompletos",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            int idUser = obtenerIdUsuarioActual();

            Socio s = new Socio(nombre, apellido, dni, estado, idUser);
            s.setCategoria(categoria);
            s.setPeriodicidad("Mensual");
            s.setFotoRuta(rutaFotoActual);

            dao.insertar(s);
            cargarTablaBD();
            limpiarInputs();

            JOptionPane.showMessageDialog(this,
                    "Socio registrado con éxito.",
                    "Operación exitosa",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al insertar socio:\n" + ex.getMessage(),
                    "Error BD",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTablaBD() {
        try {
            modeloTabla.setRowCount(0);
            List<Socio> lista = dao.listar();

            for (Socio s : lista) {
                modeloTabla.addRow(new Object[]{
                        s.getId(), s.getNombre(), s.getApellido(),
                        s.getDni(), s.getEstado(), s.getCategoria()
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al cargar socios:\n" + ex.getMessage(),
                    "Error BD",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarSeleccion() {
        int fila = tablaSocios.getSelectedRow();
        if (fila == -1) return;

        String dni = modeloTabla.getValueAt(fila, 3).toString();

        try {
            List<Socio> lista = dao.buscar(dni);
            if (!lista.isEmpty()) {
                Socio s = lista.get(0);
                rutaFotoActual = s.getFotoRuta();  // Recuperar foto
            }
        } catch (SQLException ignored) {}

        idSeleccionado = (int) modeloTabla.getValueAt(fila, 0);

        txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
        txtApellido.setText(modeloTabla.getValueAt(fila, 2).toString());
        txtDni.setText(modeloTabla.getValueAt(fila, 3).toString());
        cbEstado.setSelectedItem(modeloTabla.getValueAt(fila, 4).toString());
        cbCategoria.setSelectedItem(modeloTabla.getValueAt(fila, 5).toString());
    }

    private void actualizarSocio() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un socio para modificar.",
                    "Selección requerida",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int idUser = obtenerIdUsuarioActual();

            Socio s = new Socio(
                    idSeleccionado,
                    txtNombre.getText().trim(),
                    txtApellido.getText().trim(),
                    txtDni.getText().trim(),
                    cbEstado.getSelectedItem().toString(),
                    idUser
            );

            s.setCategoria(cbCategoria.getSelectedItem().toString());
            s.setPeriodicidad("Mensual");
            s.setFotoRuta(rutaFotoActual);

            dao.actualizar(s);
            cargarTablaBD();
            limpiar();

            JOptionPane.showMessageDialog(this,
                    "Socio actualizado correctamente.",
                    "Operación exitosa",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al actualizar socio:\n" + ex.getMessage(),
                    "Error BD",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarSocio() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un socio para eliminar.",
                    "Selección requerida",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int confirmacion = JOptionPane.showConfirmDialog(
                    this,
                    "¿Está seguro de eliminar este socio?\nEsta acción no se puede deshacer.",
                    "Confirmar eliminación",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (confirmacion != JOptionPane.YES_OPTION) return;

            dao.eliminar(idSeleccionado);
            cargarTablaBD();
            limpiar();

            JOptionPane.showMessageDialog(this,
                    "Socio eliminado correctamente.",
                    "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al eliminar socio:\n" + ex.getMessage(),
                    "Error BD",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscar() {
        String texto = txtBuscar.getText().trim();

        if (texto.isEmpty()) {
            cargarTablaBD();
            return;
        }

        try {
            modeloTabla.setRowCount(0);

            for (Socio s : dao.buscar(texto)) {
                modeloTabla.addRow(new Object[]{
                        s.getId(), s.getNombre(), s.getApellido(),
                        s.getDni(), s.getEstado(), s.getCategoria()
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error en búsqueda:\n" + ex.getMessage(),
                    "Error BD",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarInputs() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        cbEstado.setSelectedIndex(0);
        cbCategoria.setSelectedIndex(1);
        rutaFotoActual = null;
    }

    private void limpiar() {
        limpiarInputs();
        txtBuscar.setText("");
        idSeleccionado = -1;
        tablaSocios.clearSelection();
    }
}
