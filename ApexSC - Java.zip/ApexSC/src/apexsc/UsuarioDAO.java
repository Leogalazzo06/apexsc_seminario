package apexsc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // INSERTAR
    public void insertar(Usuario u) throws SQLException {
        String sql = "INSERT INTO usuario (username, password, rol) VALUES (?,?,?)";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getRol());
            ps.executeUpdate();
        }
    }

    // LISTAR
    public List<Usuario> listar() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT id_usuario, username, password, rol FROM usuario ORDER BY id_usuario";

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Usuario u = new Usuario(
                        rs.getInt("id_usuario"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("rol")
                );
                lista.add(u);
            }
        }
        return lista;
    }

    // ACTUALIZAR
    public void actualizar(Usuario u) throws SQLException {
        String sql = "UPDATE usuario SET username=?, password=?, rol=? WHERE id_usuario=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, u.getUsername());
            ps.setString(2, u.getPassword());
            ps.setString(3, u.getRol());
            ps.setInt(4, u.getId());
            ps.executeUpdate();
        }
    }

    // ELIMINAR
    public void eliminar(int id) throws SQLException {
        String sql = "DELETE FROM usuario WHERE id_usuario=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    // BUSCAR (por username o rol)
    public List<Usuario> buscar(String texto) throws SQLException {
        List<Usuario> lista = new ArrayList<>();

        String sql = """
            SELECT id_usuario, username, password, rol
            FROM usuario
            WHERE LOWER(username) LIKE ? OR LOWER(rol) LIKE ?
            ORDER BY id_usuario
            """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String like = "%" + texto.toLowerCase() + "%";
            ps.setString(1, like);
            ps.setString(2, like);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Usuario u = new Usuario(
                        rs.getInt("id_usuario"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("rol")
                );
                lista.add(u);
            }
        }
        return lista;
    }

    // USADO POR LOGIN
    public Usuario buscarPorUsernameYPassword(String username, String password) throws SQLException {
        String sql = "SELECT id_usuario, username, password, rol FROM usuario WHERE username=? AND password=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(
                            rs.getInt("id_usuario"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("rol")
                    );
                }
            }
        }
        return null;
    }
}
