package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class VentanaUsuarios extends JFrame {

    private JTextField txtUsuario, txtBuscar;
    private JPasswordField txtContrasena;
    private JComboBox<String> cbRol;
    private JTable tabla;
    private DefaultTableModel modelo;

    private UsuarioDAO usuarioDAO;
    private int idSeleccionado = -1;

    public VentanaUsuarios() {

        setTitle("Gestión de Usuarios del Sistema");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10,10));

        Color azul = new Color(0,51,102);
        Color dorado = new Color(218,165,32);
        Color fondo = new Color(245,247,255);

        usuarioDAO = new UsuarioDAO();

        // PANEL SUPERIOR (FORM + BOTONES) 
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(fondo);
        top.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(fondo);
        form.setBorder(BorderFactory.createTitledBorder("Registrar / Editar Usuario"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,10,5,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtUsuario = new JTextField(16);
        txtContrasena = new JPasswordField(16);
        cbRol = new JComboBox<>(new String[]{"Administrador", "Cajero"});

        gbc.gridx=0; gbc.gridy=0; form.add(new JLabel("Usuario:"), gbc);
        gbc.gridx=1; form.add(txtUsuario, gbc);

        gbc.gridx=0; gbc.gridy=1; form.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx=1; form.add(txtContrasena, gbc);

        gbc.gridx=0; gbc.gridy=2; form.add(new JLabel("Rol:"), gbc);
        gbc.gridx=1; form.add(cbRol, gbc);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER,20,5));
        botones.setBackground(fondo);

        JButton btnAgregar = crearBoton("Agregar", azul, dorado);
        JButton btnActualizar = crearBoton("Actualizar", azul, dorado);
        JButton btnEliminar = crearBoton("Eliminar", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);

        botones.add(btnAgregar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        top.add(form, BorderLayout.CENTER);
        top.add(botones, BorderLayout.SOUTH);

        //  PANEL CENTRAL (BUSQUEDA + TABLA)
        JPanel center = new JPanel(new BorderLayout(0,8));
        center.setBackground(fondo);
        center.setBorder(BorderFactory.createEmptyBorder(0,10,10,10));

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
        busqueda.setBackground(fondo);
        busqueda.add(new JLabel("Buscar usuario (usuario / rol):"));
        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);

        modelo = new DefaultTableModel(
                new String[]{"ID", "Usuario", "Rol"},
                0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tabla = new JTable(modelo);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.getSelectionModel().addListSelectionListener(e -> cargarSeleccion());

        JScrollPane scroll = new JScrollPane(tabla);

        center.add(busqueda, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        // Eventos
        btnAgregar.addActionListener(e -> agregar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiar());
        btnBuscar.addActionListener(e -> buscar());

        cargarTabla();

        setVisible(true);
    }

    private JButton crearBoton(String texto, Color fondo, Color borde) {
        JButton b = new JButton(texto);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(borde, 2));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void cargarTabla() {
        try {
            modelo.setRowCount(0);
            for (Usuario u : usuarioDAO.listar()) {
                modelo.addRow(new Object[]{
                        u.getId(),
                        u.getUsername(),
                        u.getRol()
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando usuarios:\n"+e.getMessage());
        }
    }

    private void cargarSeleccion() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) return;

        idSeleccionado = (int) modelo.getValueAt(fila, 0);

        txtUsuario.setText(modelo.getValueAt(fila,1).toString());
        cbRol.setSelectedItem(modelo.getValueAt(fila,2).toString());
        // no mostramos la contraseña
        txtContrasena.setText("");
    }

    private void agregar() {
        try {
            String user = txtUsuario.getText().trim();
            String pass = new String(txtContrasena.getPassword());
            String rol = cbRol.getSelectedItem().toString();

            if (user.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete usuario y contraseña.");
                return;
            }

            Usuario u = new Usuario(user, pass, rol);

            usuarioDAO.insertar(u);
            cargarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Usuario agregado.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void actualizar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un usuario.");
            return;
        }

        try {
            String user = txtUsuario.getText().trim();
            String pass = new String(txtContrasena.getPassword());
            String rol = cbRol.getSelectedItem().toString();

            if (user.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El usuario no puede estar vacío.");
                return;
            }

            // Si contraseña está vacía, mantenemos la anterior
            Usuario actual = null;
            for (Usuario uBase : usuarioDAO.listar()) {
                if (uBase.getId() == idSeleccionado) {
                    actual = uBase;
                    break;
                }
            }
            String passFinal = pass.isEmpty() && actual != null ? actual.getPassword() : pass;

            Usuario u = new Usuario(idSeleccionado, user, passFinal, rol);

            usuarioDAO.actualizar(u);
            cargarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Usuario actualizado.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void eliminar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un usuario.");
            return;
        }

        try {
            usuarioDAO.eliminar(idSeleccionado);
            cargarTabla();
            limpiar();
            JOptionPane.showMessageDialog(this, "Usuario eliminado.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: "+e.getMessage());
        }
    }

    private void buscar() {
        String q = txtBuscar.getText().trim();

        if (q.isEmpty()) {
            cargarTabla();
            return;
        }

        try {
            modelo.setRowCount(0);
            for (Usuario u : usuarioDAO.buscar(q)) {
                modelo.addRow(new Object[]{
                        u.getId(),
                        u.getUsername(),
                        u.getRol()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error buscando:\n"+e.getMessage());
        }
    }

    private void limpiar() {
        txtUsuario.setText("");
        txtContrasena.setText("");
        txtBuscar.setText("");
        idSeleccionado = -1;
    }
}
