package apexsc;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AbonoPiletaDAO {

    
    // INSERTAR
    public void insertar(AbonoPileta a) throws SQLException {

        String sql = """
            INSERT INTO abono_pileta 
            (id_socio, fecha_inicio, fecha_fin, precio, estado, estado_pago, tipo)
            VALUES (?,?,?,?,?,?,?)
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, a.getSocio().getId());
            ps.setDate(2, Date.valueOf(a.getFechaInicio()));
            ps.setDate(3, Date.valueOf(a.getFechaFin()));
            ps.setDouble(4, a.getPrecio());
            ps.setString(5, a.getEstado());
            ps.setString(6, a.getEstadoPago());
            ps.setString(7, a.getTipo());

            ps.executeUpdate();
        }
    }


    // LISTAR
    public List<AbonoPileta> listar() throws SQLException {

        List<AbonoPileta> lista = new ArrayList<>();

        String sql = """
            SELECT a.id_abono, a.fecha_inicio, a.fecha_fin, a.precio, 
                   a.estado, a.estado_pago, a.tipo,
                   s.id_socio, s.nombre, s.apellido, s.dni, 
                   s.estado AS estado_socio, s.id_usuario_creador
            FROM abono_pileta a
            JOIN socio s ON a.id_socio = s.id_socio
            ORDER BY a.id_abono DESC
        """;

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado_socio"),
                        rs.getInt("id_usuario_creador")
                );

                AbonoPileta a = new AbonoPileta(
                        rs.getInt("id_abono"),
                        s,
                        rs.getDate("fecha_inicio").toLocalDate(),
                        rs.getDate("fecha_fin").toLocalDate(),
                        rs.getDouble("precio"),
                        rs.getString("estado"),
                        rs.getString("estado_pago"),
                        rs.getString("tipo")
                );

                lista.add(a);
            }
        }

        return lista;
    }

 
    // ACTUALIZAR
    public void actualizar(AbonoPileta a) throws SQLException {

        String sql = """
            UPDATE abono_pileta 
            SET id_socio=?, fecha_inicio=?, fecha_fin=?, precio=?, 
                estado=?, estado_pago=?, tipo=?
            WHERE id_abono=?
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, a.getSocio().getId());
            ps.setDate(2, Date.valueOf(a.getFechaInicio()));
            ps.setDate(3, Date.valueOf(a.getFechaFin()));
            ps.setDouble(4, a.getPrecio());
            ps.setString(5, a.getEstado());
            ps.setString(6, a.getEstadoPago());
            ps.setString(7, a.getTipo());
            ps.setInt(8, a.getId());

            ps.executeUpdate();
        }
    }

 
    // ELIMINAR
    public void eliminar(int idAbono) throws SQLException {

        String sql = "DELETE FROM abono_pileta WHERE id_abono=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idAbono);
            ps.executeUpdate();
        }
    }

 
    // BUSCAR
    public List<AbonoPileta> buscar(String texto) throws SQLException {

        List<AbonoPileta> lista = new ArrayList<>();

        String sql = """
            SELECT a.id_abono, a.fecha_inicio, a.fecha_fin, a.precio,
                   a.estado, a.estado_pago, a.tipo,
                   s.id_socio, s.nombre, s.apellido, s.dni, 
                   s.estado AS estado_socio, s.id_usuario_creador
            FROM abono_pileta a
            JOIN socio s ON a.id_socio = s.id_socio
            WHERE LOWER(s.nombre) LIKE ? 
               OR LOWER(s.apellido) LIKE ? 
               OR s.dni LIKE ? 
               OR LOWER(a.estado_pago) LIKE ?
               OR LOWER(a.estado) LIKE ?
               OR LOWER(a.tipo) LIKE ?
            ORDER BY a.id_abono DESC
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String like = "%" + texto.toLowerCase() + "%";

            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, "%" + texto + "%");
            ps.setString(4, like);
            ps.setString(5, like);
            ps.setString(6, like);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado_socio"),
                        rs.getInt("id_usuario_creador")
                );

                AbonoPileta a = new AbonoPileta(
                        rs.getInt("id_abono"),
                        s,
                        rs.getDate("fecha_inicio").toLocalDate(),
                        rs.getDate("fecha_fin").toLocalDate(),
                        rs.getDouble("precio"),
                        rs.getString("estado"),
                        rs.getString("estado_pago"),
                        rs.getString("tipo")
                );

                lista.add(a);
            }
        }

        return lista;
    }

 
    // BUSCAR POR SOCIO
    public List<AbonoPileta> buscarPorSocio(int idSocio) throws SQLException {
        List<AbonoPileta> lista = new ArrayList<>();

        String sql = """
            SELECT a.id_abono, a.fecha_inicio, a.fecha_fin, a.precio,
                   a.estado, a.estado_pago, a.tipo,
                   s.id_socio, s.nombre, s.apellido, s.dni, 
                   s.estado AS estado_socio, s.id_usuario_creador
            FROM abono_pileta a
            JOIN socio s ON a.id_socio = s.id_socio
            WHERE a.id_socio = ?
            ORDER BY a.fecha_inicio DESC
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idSocio);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado_socio"),
                        rs.getInt("id_usuario_creador")
                );

                AbonoPileta a = new AbonoPileta(
                        rs.getInt("id_abono"),
                        s,
                        rs.getDate("fecha_inicio").toLocalDate(),
                        rs.getDate("fecha_fin").toLocalDate(),
                        rs.getDouble("precio"),
                        rs.getString("estado"),
                        rs.getString("estado_pago"),
                        rs.getString("tipo")
                );

                lista.add(a);
            }
        }

        return lista;
    }

    
    // BUSCAR ABONOS VIGENTES
    public List<AbonoPileta> buscarVigentes() throws SQLException {
        List<AbonoPileta> lista = new ArrayList<>();

        String sql = """
            SELECT a.id_abono, a.fecha_inicio, a.fecha_fin, a.precio,
                   a.estado, a.estado_pago, a.tipo,
                   s.id_socio, s.nombre, s.apellido, s.dni, 
                   s.estado AS estado_socio, s.id_usuario_creador
            FROM abono_pileta a
            JOIN socio s ON a.id_socio = s.id_socio
            WHERE a.estado = 'Vigente'
            ORDER BY a.fecha_fin ASC
        """;

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado_socio"),
                        rs.getInt("id_usuario_creador")
                );

                AbonoPileta a = new AbonoPileta(
                        rs.getInt("id_abono"),
                        s,
                        rs.getDate("fecha_inicio").toLocalDate(),
                        rs.getDate("fecha_fin").toLocalDate(),
                        rs.getDouble("precio"),
                        rs.getString("estado"),
                        rs.getString("estado_pago"),
                        rs.getString("tipo")
                );

                lista.add(a);
            }
        }

        return lista;
    }


    // ACTUALIZAR ESTADOS AUTOMÁTICAMENTE
    public void actualizarEstadosAutomaticamente() throws SQLException {
        String sqlUpdateVencidos = """
            UPDATE abono_pileta 
            SET estado = 'Vencido' 
            WHERE fecha_fin < CURRENT_DATE AND estado = 'Vigente'
        """;

        String sqlUpdateVigentes = """
            UPDATE abono_pileta 
            SET estado = 'Vigente' 
            WHERE fecha_fin >= CURRENT_DATE AND estado = 'Vencido'
        """;

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement()) {

            st.executeUpdate(sqlUpdateVencidos);
            st.executeUpdate(sqlUpdateVigentes);
        }
    }
}
