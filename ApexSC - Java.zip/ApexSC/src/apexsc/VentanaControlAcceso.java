package apexsc;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

public class VentanaControlAcceso extends JFrame {

    private final JTextField txtQR;
    private final JTextField txtDNI;

    private final JLabel lblEvento;
    private final JLabel lblNombre;
    private final JLabel lblTipo;
    private final JLabel lblPrecio;
    private final JLabel lblUsado;

    private final EntradaDAO entradaDAO;

    private Entrada entradaActual = null;

    public VentanaControlAcceso() {

        setTitle("Control de Accesos - Validación de Entradas");
        setSize(700, 450);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10,10));

        entradaDAO = new EntradaDAO();

        Color azul = new Color(0,51,102);
        Color dorado = new Color(218,165,32);
        Color fondo = new Color(245,247,255);

        // PANEL SUPERIOR
        JPanel top = new JPanel(new GridBagLayout());
        top.setBackground(fondo);
        top.setBorder(new EmptyBorder(15,15,15,15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,8,8,8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtQR = new JTextField(20);
        txtDNI = new JTextField(12);

        JButton btnValidarQR = crearBoton("Validar por QR", azul, dorado);
        JButton btnValidarDNI = crearBoton("Buscar por DNI", azul, dorado);

        // FILA 1
        gbc.gridx=0; gbc.gridy=0; top.add(new JLabel("Código QR:"), gbc);
        gbc.gridx=1; top.add(txtQR, gbc);
        gbc.gridx=2; top.add(btnValidarQR, gbc);

        // FILA 2
        gbc.gridx=0; gbc.gridy=1; top.add(new JLabel("DNI:"), gbc);
        gbc.gridx=1; top.add(txtDNI, gbc);
        gbc.gridx=2; top.add(btnValidarDNI, gbc);

        // PANEL CENTRAL (Datos)
        JPanel center = new JPanel(new GridLayout(6,1,5,5));
        center.setBackground(fondo);
        center.setBorder(BorderFactory.createTitledBorder("Resultado de Validación"));

        lblEvento = new JLabel("Evento: ---");
        lblNombre = new JLabel("Nombre: ---");
        lblTipo   = new JLabel("Tipo: ---");
        lblPrecio = new JLabel("Precio: ---");
        lblUsado  = new JLabel("Estado: ---");

        lblEvento.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblNombre.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblTipo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblUsado.setFont(new Font("Segoe UI", Font.BOLD, 16));

        center.add(lblEvento);
        center.add(lblNombre);
        center.add(lblTipo);
        center.add(lblPrecio);
        center.add(lblUsado);

        // PANEL INFERIOR
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER,20,10));
        bottom.setBackground(fondo);

        JButton btnMarcar = crearBoton("Marcar como Usada", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);

        bottom.add(btnMarcar);
        bottom.add(btnLimpiar);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        // EVENTOS
        btnValidarQR.addActionListener(e -> validarPorQR());
        btnValidarDNI.addActionListener(e -> validarPorDNI());
        btnMarcar.addActionListener(e -> marcarUsada());
        btnLimpiar.addActionListener(e -> limpiar());

        setVisible(true);
    }

  
    // VALIDACIÓN POR QR

    private void validarPorQR() {

        String qr = txtQR.getText().trim();
        if (qr.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Ingrese un código QR.");
            return;
        }

        try {
            entradaActual = entradaDAO.buscarPorQR(qr);

            if (entradaActual == null) {
                JOptionPane.showMessageDialog(this,"QR no encontrado.");
                limpiarDatos();
                return;
            }

            mostrarDatos();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Error buscando QR:\n" + ex.getMessage());
        }
    }

   
    // VALIDACIÓN POR DNI
   
    private void validarPorDNI() {

        String dni = txtDNI.getText().trim();
        if (dni.isEmpty()) {
            JOptionPane.showMessageDialog(this,"Ingrese un DNI.");
            return;
        }

        try {
            // Reutilizamos buscar()
            var lista = entradaDAO.buscar(dni);

            if (lista.isEmpty()) {
                JOptionPane.showMessageDialog(this,"No se encontró entrada para ese DNI.");
                limpiarDatos();
                return;
            }

            // Tomamos la más reciente
            entradaActual = lista.get(0);
            mostrarDatos();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Error buscando:\n" + ex.getMessage());
        }
    }


    // MOSTRAR DATOS EN PANTALLA

   private void mostrarDatos() {

    try {
        EventoDAO eventoDAO = new EventoDAO();
        Evento ev = eventoDAO.buscarPorId(entradaActual.getIdEvento());

        if (ev != null) {
            lblEvento.setText("Evento: " + ev.getNombre() + " (" + ev.getLugar() + ")");
        } else {
            lblEvento.setText("Evento: [No encontrado]");
        }

    } catch (Exception e) {
        lblEvento.setText("Evento: [Error]");
    }

    lblNombre.setText("Nombre: " + entradaActual.getNombreComprador());
    lblTipo.setText("Tipo: " + entradaActual.getTipo());
    lblPrecio.setText("Precio: $" + entradaActual.getPrecio());

    if (entradaActual.isUsado()) {
        lblUsado.setText("Estado: YA INGRESÓ");
        lblUsado.setForeground(Color.RED);
    } else {
        lblUsado.setText("Estado: HABILITADO");
        lblUsado.setForeground(new Color(0,128,0));
    }
}


  
    // MARCAR COMO USADA

    private void marcarUsada() {

        if (entradaActual == null) {
            JOptionPane.showMessageDialog(this,"Debe validar una entrada primero.");
            return;
        }

        if (entradaActual.isUsado()) {
            JOptionPane.showMessageDialog(this,"Esta entrada ya fue utilizada.");
            return;
        }

        try {
            entradaDAO.marcarUsada(entradaActual.getId());
            entradaActual.setUsado(true);
            mostrarDatos();
            JOptionPane.showMessageDialog(this,"Entrada marcada como usada.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Error:\n" + ex.getMessage());
        }
    }


    // LIMPIAR
 
    private void limpiar() {
        txtQR.setText("");
        txtDNI.setText("");
        entradaActual = null;
        limpiarDatos();
    }

    private void limpiarDatos() {
        lblEvento.setText("Evento: ---");
        lblNombre.setText("Nombre: ---");
        lblTipo.setText("Tipo: ---");
        lblPrecio.setText("Precio: ---");
        lblUsado.setText("Estado: ---");
        lblUsado.setForeground(Color.BLACK);
    }

 
    // BOTÓN ESTILIZADO

    private JButton crearBoton(String texto, Color azul, Color dorado) {
        JButton b = new JButton(texto);
        b.setBackground(azul);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBorder(BorderFactory.createLineBorder(dorado,2));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));

        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b.setBackground(dorado);
                b.setForeground(azul);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b.setBackground(azul);
                b.setForeground(Color.WHITE);
            }
        });

        return b;
    }
}
