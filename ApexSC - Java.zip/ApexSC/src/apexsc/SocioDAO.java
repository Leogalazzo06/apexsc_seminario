package apexsc;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SocioDAO {

    
    // INSERTAR SOCIO 
    public void insertar(Socio s) throws SQLException {

        String sql = """
            INSERT INTO socio 
            (dni, nombre, apellido, estado, categoria, periodicidad, id_usuario_creador, foto_ruta)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, s.getDni());
            ps.setString(2, s.getNombre());
            ps.setString(3, s.getApellido());
            ps.setString(4, s.getEstado());
            ps.setString(5, s.getCategoria());
            ps.setString(6, s.getPeriodicidad());
            ps.setInt(7, s.getIdUsuarioCreador());
            ps.setString(8, s.getFotoRuta());  // Nuevo campo

            ps.executeUpdate();
        }
    }

 
    // LISTAR SOCIOS 
 
    public List<Socio> listar() throws SQLException {

        List<Socio> lista = new ArrayList<>();

        String sql = "SELECT * FROM socio ORDER BY id_socio ASC";

        try (Connection con = Conexion.obtenerConexion();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {

                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado"),
                        rs.getInt("id_usuario_creador")
                );

                s.setCategoria(rs.getString("categoria"));
                s.setPeriodicidad(rs.getString("periodicidad"));
                s.setFotoRuta(rs.getString("foto_ruta")); // Nuevo

                lista.add(s);
            }
        }

        return lista;
    }

  
    // ACTUALIZAR SOCIO 
 
    public void actualizar(Socio s) throws SQLException {

        String sql = """
            UPDATE socio SET 
                nombre=?, apellido=?, dni=?, estado=?, 
                categoria=?, periodicidad=?, foto_ruta=?
            WHERE id_socio=?
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, s.getNombre());
            ps.setString(2, s.getApellido());
            ps.setString(3, s.getDni());
            ps.setString(4, s.getEstado());
            ps.setString(5, s.getCategoria());
            ps.setString(6, s.getPeriodicidad());
            ps.setString(7, s.getFotoRuta());   // Nuevo
            ps.setInt(8, s.getId());

            ps.executeUpdate();
        }
    }

 
    // ELIMINAR SOCIO
    public void eliminar(int id) throws SQLException {

        String sql = "DELETE FROM socio WHERE id_socio=?";

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }


    // BUSCAR SOCIOS 

    public List<Socio> buscar(String texto) throws SQLException {

        List<Socio> lista = new ArrayList<>();

        String sql = """
            SELECT * FROM socio
            WHERE LOWER(nombre) LIKE ?
               OR LOWER(apellido) LIKE ?
               OR dni LIKE ?
        """;

        try (Connection con = Conexion.obtenerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String like = "%" + texto.toLowerCase() + "%";

            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, "%" + texto + "%");

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Socio s = new Socio(
                        rs.getInt("id_socio"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"),
                        rs.getString("estado"),
                        rs.getInt("id_usuario_creador")
                );

                s.setCategoria(rs.getString("categoria"));
                s.setPeriodicidad(rs.getString("periodicidad"));
                s.setFotoRuta(rs.getString("foto_ruta")); // Nuevo

                lista.add(s);
            }
        }

        return lista;
    }
}
