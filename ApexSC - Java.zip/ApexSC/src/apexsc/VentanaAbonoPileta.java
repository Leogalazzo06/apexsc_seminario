package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class VentanaAbonoPileta extends JFrame {

    private final JComboBox<Socio> cbSocio;
    private final JTextField txtPrecio, txtBuscar;
    private final JComboBox<Integer> cbDiaInicio, cbMesInicio, cbAnioInicio;
    private final JComboBox<Integer> cbDiaFin, cbMesFin, cbAnioFin;
    private final JComboBox<String> cbEstadoPago, cbTipoAbono;
    private final JLabel lblPrecioCalculado;

    private final JTable tabla;
    private final DefaultTableModel modelo;

    private final AbonoPiletaDAO abonoDAO;
    private final SocioDAO socioDAO;

    private int idSeleccionado = -1;
    private final int idUsuario; // recibido desde ApexSC

   
    //  CONSTRUCTOR 

    public VentanaAbonoPileta(int idUsuario) {

        this.idUsuario = idUsuario;

        setTitle("Gestión de Abonos de Pileta - Individual y Familiar");
        setSize(1100, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10,10));

        Color azul = new Color(0,51,102);
        Color dorado = new Color(218,165,32);
        Color fondo = new Color(245,247,255);

        abonoDAO = new AbonoPiletaDAO();
        socioDAO = new SocioDAO();

        // PANEL SUPERIOR
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(fondo);
        top.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(fondo);
        form.setBorder(BorderFactory.createTitledBorder("Registrar / Editar Abono"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,10,5,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // CAMPOS
        cbSocio = new JComboBox<>();
        txtPrecio = new JTextField(10);
        cbDiaInicio = new JComboBox<>();
        cbMesInicio = new JComboBox<>();
        cbAnioInicio = new JComboBox<>();
        cbDiaFin = new JComboBox<>();
        cbMesFin = new JComboBox<>();
        cbAnioFin = new JComboBox<>();
        cbEstadoPago = new JComboBox<>(new String[]{"Pendiente", "Pagado"});
        cbTipoAbono = new JComboBox<>(new String[]{"INDIVIDUAL", "FAMILIAR"});
        lblPrecioCalculado = new JLabel("$0.00");
        lblPrecioCalculado.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPrecioCalculado.setForeground(azul);

        // DIAS
        for(int i=1;i<=31;i++){
            cbDiaInicio.addItem(i);
            cbDiaFin.addItem(i);
        }

        // MESES
        for(int i=1;i<=12;i++){
            cbMesInicio.addItem(i);
            cbMesFin.addItem(i);
        }

        // AÑOS
        int anio = LocalDate.now().getYear();
        for(int i=anio;i<=anio+5;i++){
            cbAnioInicio.addItem(i);
            cbAnioFin.addItem(i);
        }

        // FILAS DEL FORMULARIO 
        gbc.gridx=0; gbc.gridy=0; form.add(new JLabel("Socio:"), gbc);
        gbc.gridx=1; gbc.gridwidth=3; form.add(cbSocio, gbc); gbc.gridwidth=1;

        gbc.gridx=0; gbc.gridy=1; form.add(new JLabel("Fecha Inicio:"), gbc);
        JPanel fInicio = new JPanel(new FlowLayout(FlowLayout.LEFT,5,0));
        fInicio.setBackground(fondo);
        fInicio.add(cbDiaInicio); fInicio.add(cbMesInicio); fInicio.add(cbAnioInicio);
        gbc.gridx=1; gbc.gridwidth=3; form.add(fInicio, gbc); gbc.gridwidth=1;

        gbc.gridx=0; gbc.gridy=2; form.add(new JLabel("Fecha Fin:"), gbc);
        JPanel fFin = new JPanel(new FlowLayout(FlowLayout.LEFT,5,0));
        fFin.setBackground(fondo);
        fFin.add(cbDiaFin); fFin.add(cbMesFin); fFin.add(cbAnioFin);
        gbc.gridx=1; gbc.gridwidth=3; form.add(fFin, gbc); gbc.gridwidth=1;

        gbc.gridx=0; gbc.gridy=3; form.add(new JLabel("Tipo Abono:"), gbc);
        gbc.gridx=1; form.add(cbTipoAbono, gbc);

        gbc.gridx=0; gbc.gridy=4; form.add(new JLabel("Precio Calculado:"), gbc);
        gbc.gridx=1; form.add(lblPrecioCalculado, gbc);

        gbc.gridx=0; gbc.gridy=5; form.add(new JLabel("Precio Final:"), gbc);
        gbc.gridx=1; form.add(txtPrecio, gbc);

        gbc.gridx=0; gbc.gridy=6; form.add(new JLabel("Estado Pago:"), gbc);
        gbc.gridx=1; form.add(cbEstadoPago, gbc);

        // BOTONES
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER,20,5));
        botones.setBackground(fondo);

        JButton btnAgregar = crearBoton("Registrar", azul, dorado);
        JButton btnActualizar = crearBoton("Actualizar", azul, dorado);
        JButton btnEliminar = crearBoton("Eliminar", azul, dorado);
        JButton btnPagado = crearBoton("Marcar como Pagado", azul, dorado);
        JButton btnLimpiar = crearBoton("Limpiar", azul, dorado);

        botones.add(btnAgregar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnPagado);
        botones.add(btnLimpiar);

        top.add(form, BorderLayout.CENTER);
        top.add(botones, BorderLayout.SOUTH);

        // PANEL CENTRAL
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(fondo);

        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0));
        busqueda.setBackground(fondo);
        busqueda.add(new JLabel("Buscar:"));
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);

        modelo = new DefaultTableModel(
                new String[]{"ID", "Socio", "Inicio", "Fin", "Precio", "Tipo", "Estado", "Pago"},
                0
        );

        tabla = new JTable(modelo);
        tabla.getSelectionModel().addListSelectionListener(e -> cargarSeleccion());
        JScrollPane scroll = new JScrollPane(tabla);

        center.add(busqueda, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);

        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        // ACCIONES
        btnAgregar.addActionListener(e -> agregar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnPagado.addActionListener(e -> marcarPagado());
        btnLimpiar.addActionListener(e -> limpiar());
        btnBuscar.addActionListener(e -> buscar());

        // Listener precio automático
        cbTipoAbono.addActionListener(e -> calcularPrecio());

        cargarSocios();
        cargarAbonos();
        calcularPrecio();

        setVisible(true);
    }


    // BOTÓN DISEÑADO
    private JButton crearBoton(String texto, Color f, Color b) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(f);
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createLineBorder(b,2));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }


    // CALCULAR PRECIO SEGÚN TIPO
    private void calcularPrecio() {
        String tipo = (String) cbTipoAbono.getSelectedItem();
        double precio = tipo.equals("FAMILIAR") ? 5000.00 : 3000.00;
        lblPrecioCalculado.setText("$" + precio);
        txtPrecio.setText(String.valueOf(precio));
    }

 
    // CARGAS
    private void cargarSocios() {
        try {
            cbSocio.removeAllItems();
            for(Socio s : socioDAO.listar()) {
                cbSocio.addItem(s);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error cargando socios: "+e.getMessage());
        }
    }

    private void cargarAbonos() {
        try {
            modelo.setRowCount(0);
            for(AbonoPileta a : abonoDAO.listar()) {
                modelo.addRow(new Object[]{
                        a.getId(),
                        a.getSocio(),
                        a.getFechaInicio(),
                        a.getFechaFin(),
                        a.getPrecio(),
                        a.getTipo(),
                        a.getEstado(),
                        a.getEstadoPago()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error cargando abonos: "+e.getMessage());
        }
    }


    // AGREGAR
    private void agregar() {
        try {
            Socio s = (Socio) cbSocio.getSelectedItem();
            if (s == null) {
                JOptionPane.showMessageDialog(this, "Seleccione un socio.");
                return;
            }

            LocalDate inicio = LocalDate.of(
                    (Integer) cbAnioInicio.getSelectedItem(),
                    (Integer) cbMesInicio.getSelectedItem(),
                    (Integer) cbDiaInicio.getSelectedItem()
            );

            LocalDate fin = LocalDate.of(
                    (Integer) cbAnioFin.getSelectedItem(),
                    (Integer) cbMesFin.getSelectedItem(),
                    (Integer) cbDiaFin.getSelectedItem()
            );

            if (fin.isBefore(inicio)) {
                JOptionPane.showMessageDialog(this, "La fecha fin no puede ser anterior a inicio.");
                return;
            }

            double precio = Double.parseDouble(txtPrecio.getText());
            String estadoPago = (String) cbEstadoPago.getSelectedItem();
            String tipoAbono = (String) cbTipoAbono.getSelectedItem();

            AbonoPileta a = new AbonoPileta(s, inicio, fin, precio, tipoAbono);
            a.setEstadoPago(estadoPago);

            abonoDAO.insertar(a);
            cargarAbonos();
            limpiar();

            JOptionPane.showMessageDialog(this, "Abono " + tipoAbono + " registrado correctamente.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());
        }
    }

    
    // CARGAR SELECCIÓN
    private void cargarSeleccion() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) return;

        idSeleccionado = (int) modelo.getValueAt(fila, 0);

        Socio s = (Socio) modelo.getValueAt(fila, 1);
        for (int i=0;i<cbSocio.getItemCount();i++){
            if(cbSocio.getItemAt(i).getId() == s.getId()){
                cbSocio.setSelectedIndex(i);
                break;
            }
        }

        LocalDate inicio = (LocalDate) modelo.getValueAt(fila, 2);
        cbDiaInicio.setSelectedItem(inicio.getDayOfMonth());
        cbMesInicio.setSelectedItem(inicio.getMonthValue());
        cbAnioInicio.setSelectedItem(inicio.getYear());

        LocalDate fin = (LocalDate) modelo.getValueAt(fila, 3);
        cbDiaFin.setSelectedItem(fin.getDayOfMonth());
        cbMesFin.setSelectedItem(fin.getMonthValue());
        cbAnioFin.setSelectedItem(fin.getYear());

        txtPrecio.setText(String.valueOf(modelo.getValueAt(fila,4)));
        cbTipoAbono.setSelectedItem((String) modelo.getValueAt(fila, 5));
        cbEstadoPago.setSelectedItem((String) modelo.getValueAt(fila, 7));
    }

   
    // ACTUALIZAR
    private void actualizar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this,"Seleccione un registro.");
            return;
        }

        try {
            Socio s = (Socio) cbSocio.getSelectedItem();

            LocalDate inicio = LocalDate.of(
                    (Integer) cbAnioInicio.getSelectedItem(),
                    (Integer) cbMesInicio.getSelectedItem(),
                    (Integer) cbDiaInicio.getSelectedItem()
            );

            LocalDate fin = LocalDate.of(
                    (Integer) cbAnioFin.getSelectedItem(),
                    (Integer) cbMesFin.getSelectedItem(),
                    (Integer) cbDiaFin.getSelectedItem()
            );

            double precio = Double.parseDouble(txtPrecio.getText());
            String estadoPago = (String) cbEstadoPago.getSelectedItem();
            String tipoAbono = (String) cbTipoAbono.getSelectedItem();

            AbonoPileta a = new AbonoPileta(s, inicio, fin, precio, tipoAbono);
            a.setId(idSeleccionado);
            a.setEstadoPago(estadoPago);

            abonoDAO.actualizar(a);
            cargarAbonos();
            limpiar();

            JOptionPane.showMessageDialog(this,"Abono " + tipoAbono + " actualizado.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());
        }
    }

  
    // ELIMINAR
    private void eliminar() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this,"Seleccione un registro.");
            return;
        }

        try {
            abonoDAO.eliminar(idSeleccionado);
            cargarAbonos();
            limpiar();
            JOptionPane.showMessageDialog(this,"Registro eliminado.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error eliminando: "+e.getMessage());
        }
    }


    // MARCAR COMO PAGADO
    private void marcarPagado() {
        if (idSeleccionado == -1) {
            JOptionPane.showMessageDialog(this,"Seleccione un registro.");
            return;
        }

        try {
            Socio s = (Socio) cbSocio.getSelectedItem();
            LocalDate inicio = LocalDate.of(
                    (Integer) cbAnioInicio.getSelectedItem(),
                    (Integer) cbMesInicio.getSelectedItem(),
                    (Integer) cbDiaInicio.getSelectedItem()
            );
            LocalDate fin = LocalDate.of(
                    (Integer) cbAnioFin.getSelectedItem(),
                    (Integer) cbMesFin.getSelectedItem(),
                    (Integer) cbDiaFin.getSelectedItem()
            );
            double precio = Double.parseDouble(txtPrecio.getText());
            String tipoAbono = (String) cbTipoAbono.getSelectedItem();

            AbonoPileta a = new AbonoPileta(s, inicio, fin, precio, tipoAbono);
            a.setId(idSeleccionado);
            a.setEstadoPago("Pagado");

            abonoDAO.actualizar(a);
            cargarAbonos();
            JOptionPane.showMessageDialog(this,"Abono " + tipoAbono + " marcado como pagado.");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error: "+e.getMessage());
        }
    }

  
    // BUSCAR
    private void buscar() {
        String q = txtBuscar.getText().trim();

        if (q.isEmpty()) {
            cargarAbonos();
            return;
        }

        try {
            List<AbonoPileta> lista = abonoDAO.buscar(q);
            modelo.setRowCount(0);

            for(AbonoPileta a : lista) {
                modelo.addRow(new Object[]{
                        a.getId(),
                        a.getSocio(),
                        a.getFechaInicio(),
                        a.getFechaFin(),
                        a.getPrecio(),
                        a.getTipo(),
                        a.getEstado(),
                        a.getEstadoPago()
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,"Error buscando: "+e.getMessage());
        }
    }

   
    // LIMPIAR
    private void limpiar() {
        txtPrecio.setText("");
        txtBuscar.setText("");
        cbEstadoPago.setSelectedIndex(0);
        cbTipoAbono.setSelectedIndex(0);
        idSeleccionado = -1;
        calcularPrecio();
    }
}
