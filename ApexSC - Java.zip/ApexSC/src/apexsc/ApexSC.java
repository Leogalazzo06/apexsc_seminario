package apexsc;

import javax.swing.*;
import java.awt.*;

public class ApexSC extends JFrame {

    private final Usuario usuario;

  
    // PANEL PERSONALIZADO: FONDO CON IMAGEN A PANTALLA COMPLETA

    class ImagePanel extends JPanel {

        private Image image;

        public ImagePanel(String path) {
            ImageIcon icon = new ImageIcon(getClass().getResource(path));
            this.image = icon.getImage();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);

            // Dibuja la imagen ajustada al tamaño ACTUAL del panel central
            g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
        }
    }

  
    // CONSTRUCTOR
    public ApexSC(Usuario u) {

        this.usuario = u;

        // Pantalla completa
        setTitle("Apex SC - Sistema de Gestión (" + usuario.getRol() + ")");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Colores
        Color azul = new Color(0, 51, 102);
        Color azulOscuro = new Color(0, 40, 80);
        Color dorado = new Color(218, 165, 32);

     
        // PANEL LATERAL
        JPanel lateral = new JPanel();
        lateral.setBackground(azul);
        lateral.setPreferredSize(new Dimension(260, getHeight()));
        lateral.setLayout(new BorderLayout(0, 15)); // Cambiado a BorderLayout
        lateral.setBorder(BorderFactory.createEmptyBorder(25, 20, 25, 20));

        // PANEL SUPERIOR PARA LOGO Y USUARIO
        JPanel panelSuperior = new JPanel();
        panelSuperior.setBackground(azul);
        panelSuperior.setLayout(new BoxLayout(panelSuperior, BoxLayout.Y_AXIS));
        panelSuperior.setAlignmentX(Component.CENTER_ALIGNMENT);

        // LOGO APEXSC 
        JPanel panelLogo = new JPanel();
        panelLogo.setBackground(azul);
        panelLogo.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelLogo.setMaximumSize(new Dimension(200, 100)); // Tamaño máximo fijo

        try {
            ImageIcon iconLogo = new ImageIcon(getClass().getResource("/apexsc/logo.png"));
            // Tamaño más pequeño y controlado
            Image imgLogo = iconLogo.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(imgLogo));
            lblLogo.setHorizontalAlignment(JLabel.CENTER);
            panelLogo.add(lblLogo);
        } catch (Exception ex) {
            JLabel lblTitulo = new JLabel("APEX SC", JLabel.CENTER);
            lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 26));
            lblTitulo.setForeground(Color.WHITE);
            panelLogo.add(lblTitulo);
        }

        // INFO USUARIO
        JLabel lblUsuario = new JLabel(
                "<html><center>" + usuario.getUsername() +
                        "<br>(" + usuario.getRol() + ")</center></html>",
                JLabel.CENTER
        );
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setAlignmentX(Component.CENTER_ALIGNMENT);

        panelSuperior.add(panelLogo);
        panelSuperior.add(Box.createVerticalStrut(10)); // Espacio entre logo y usuario
        panelSuperior.add(lblUsuario);

        // PANEL CENTRAL PARA BOTONES CON SCROLL
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(azul);
        panelBotones.setLayout(new GridLayout(0, 1, 0, 8)); // Espacio reducido entre botones

      
        // BOTONES ORDENADOS PROFESIONALMENTE
      

        //MÓDULOS PRINCIPALES
        JButton btnSocios = crearBotonLateral("Gestión de Socios");
        JButton btnCuotas = crearBotonLateral("Gestión de Cuotas");
        JButton btnAcceso = crearBotonLateral("Control de Accesos");
        JButton btnPileta = crearBotonLateral("Abonos de Pileta");

        panelBotones.add(btnSocios);
        panelBotones.add(btnCuotas);
        panelBotones.add(btnAcceso);
        panelBotones.add(btnPileta);

        
        panelBotones.add(crearEspacio());

        // EVENTOS
        JButton btnEventos = crearBotonLateral("Gestión de Eventos");
        JButton btnEntradas = crearBotonLateral("Entradas a Eventos");

        panelBotones.add(btnEventos);
        panelBotones.add(btnEntradas);

        // Espacio visual
        panelBotones.add(crearEspacio());

        // REPORTES Y ADMIN
        JButton btnReportes = crearBotonLateral("Reportes");
        JButton btnUsuarios = crearBotonLateral("Usuarios del Sistema");

        panelBotones.add(btnReportes);

        if (usuario.getRol().equalsIgnoreCase("Administrador")) {
            panelBotones.add(btnUsuarios);
        }

        // Espacio visual
        panelBotones.add(crearEspacio());

        // SISTEMA
        JButton btnInfo = crearBotonLateral("Acerca del Sistema");
        JButton btnSalir = crearBotonLateral("Salir");

        panelBotones.add(btnInfo);
        panelBotones.add(btnSalir);

        // SCROLL PANE PARA BOTONES (por si hay muchos botones)
        JScrollPane scrollBotones = new JScrollPane(panelBotones);
        scrollBotones.setBorder(BorderFactory.createEmptyBorder());
        scrollBotones.setBackground(azul);
        scrollBotones.getViewport().setBackground(azul);
        scrollBotones.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollBotones.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        // ORGANIZAR EN EL PANEL LATERAL
        lateral.add(panelSuperior, BorderLayout.NORTH);
        lateral.add(scrollBotones, BorderLayout.CENTER);

     
        // ASIGNAR ACCIONES A LOS BOTONES
        btnSocios.addActionListener(e -> new VentanaSocios());
        btnCuotas.addActionListener(e -> new VentanaCuotas());
        btnReportes.addActionListener(e -> new VentanaReportes());
        btnEventos.addActionListener(e -> new VentanaEventos(usuario.getId()).setVisible(true));
        btnEntradas.addActionListener(e -> new VentanaEntradas());
        btnAcceso.addActionListener(e -> new VentanaControlAcceso());
        btnPileta.addActionListener(e -> new VentanaAbonoPileta(usuario.getId()).setVisible(true));
        btnUsuarios.addActionListener(e -> new VentanaUsuarios());

        btnInfo.addActionListener(e -> JOptionPane.showMessageDialog(
                this,
                "Sistema de Gestión - Apex SC\nVersión 1.2\nDesarrollado por Leonel Agustín Galazzo",
                "Información del Sistema",
                JOptionPane.INFORMATION_MESSAGE
        ));

        btnSalir.addActionListener(e -> {
            int resp = JOptionPane.showConfirmDialog(
                    this,
                    "¿Desea salir del sistema?",
                    "Salir",
                    JOptionPane.YES_NO_OPTION
            );
            if (resp == JOptionPane.YES_OPTION) System.exit(0);
        });

      
        // PANEL CENTRAL
     
        ImagePanel central = new ImagePanel("/apexsc/banner.png");
        central.setLayout(new BorderLayout());   

    
        add(lateral, BorderLayout.WEST);
        add(central, BorderLayout.CENTER);

        setVisible(true);
    }

  
    // BOTÓN LATERAL

    private JButton crearBotonLateral(String texto) {
        JButton btn = new JButton(texto);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBackground(new Color(0, 40, 80));
        btn.setForeground(Color.WHITE);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(218, 165, 32));
                btn.setForeground(Color.BLACK);
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(new Color(0, 40, 80));
                btn.setForeground(Color.WHITE);
            }
        });

        return btn;
    }

    // MÉTODO PARA CREAR ESPACIOS VISUALES
    private JLabel crearEspacio() {
        JLabel espacio = new JLabel(" ");
        espacio.setPreferredSize(new Dimension(100, 20));
        return espacio;
    }


    // MAIN
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaLogin().setVisible(true));
    }
}