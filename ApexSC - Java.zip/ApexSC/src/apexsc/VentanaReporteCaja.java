package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public class VentanaReporteCaja extends JFrame {

    private CuotaDAO cuotaDAO = new CuotaDAO();
    private EntradaDAO entradaDAO = new EntradaDAO();
    private AbonoPiletaDAO abonoDAO = new AbonoPiletaDAO();

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    // USANDO JSPINNER - SIN DEPENDENCIAS EXTERNAS
    private JSpinner spinnerFechaDesde;
    private JSpinner spinnerFechaHasta;

    private JLabel lblTotCuotas;
    private JLabel lblTotEntradas;
    private JLabel lblTotAbonos;
    private JLabel lblTotGeneral;

    public VentanaReporteCaja() {
        setTitle("?Reporte de Caja");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout(10, 10));

    
        // PANEL SUPERIOR - FILTROS
     
        JPanel panelFiltros = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panelFiltros.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Configurar JSpinners para fechas
        spinnerFechaDesde = new JSpinner(new SpinnerDateModel());
        spinnerFechaHasta = new JSpinner(new SpinnerDateModel());

        // Formatear para mostrar solo fecha
        JSpinner.DateEditor editorDesde = new JSpinner.DateEditor(spinnerFechaDesde, "yyyy-MM-dd");
        JSpinner.DateEditor editorHasta = new JSpinner.DateEditor(spinnerFechaHasta, "yyyy-MM-dd");

        spinnerFechaDesde.setEditor(editorDesde);
        spinnerFechaHasta.setEditor(editorHasta);

        // Establecer fechas por defecto
        spinnerFechaDesde.setValue(Date.from(LocalDate.now().withDayOfMonth(1)
                .atStartOfDay(ZoneId.systemDefault()).toInstant()));
        spinnerFechaHasta.setValue(new Date()); // Fecha actual

        panelFiltros.add(new JLabel("Desde:"));
        panelFiltros.add(spinnerFechaDesde);

        panelFiltros.add(new JLabel("Hasta:"));
        panelFiltros.add(spinnerFechaHasta);

        JButton btnGenerar = new JButton("🔄 Generar Reporte");
        btnGenerar.setBackground(new Color(0, 102, 204));
        btnGenerar.setForeground(Color.WHITE);
        btnGenerar.addActionListener(e -> cargarReporte());
        panelFiltros.add(btnGenerar);

        add(panelFiltros, BorderLayout.NORTH);

      
        // TABLA
  
        modeloTabla = new DefaultTableModel(
                new String[]{"Fecha", "Tipo", "Descripción", "Monto"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tabla = new JTable(modeloTabla);
        tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tabla.setRowHeight(25);
        
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane, BorderLayout.CENTER);

    
        // PANEL INFERIOR - TOTALES
  
        JPanel panelTotales = new JPanel(new GridLayout(2, 2, 10, 10));
        panelTotales.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelTotales.setBackground(new Color(240, 240, 240));

        lblTotCuotas = new JLabel("Total Cuotas: $0.00");
        lblTotEntradas = new JLabel("Total Entradas: $0.00");
        lblTotAbonos = new JLabel("Total Abonos: $0.00");
        lblTotGeneral = new JLabel("TOTAL GENERAL: $0.00");

        Font labelFont = new Font("Arial", Font.BOLD, 14);
        lblTotCuotas.setFont(labelFont);
        lblTotEntradas.setFont(labelFont);
        lblTotAbonos.setFont(labelFont);
        lblTotGeneral.setFont(new Font("Arial", Font.BOLD, 16));
        lblTotGeneral.setForeground(new Color(0, 100, 0));

        panelTotales.add(lblTotCuotas);
        panelTotales.add(lblTotEntradas);
        panelTotales.add(lblTotAbonos);
        panelTotales.add(lblTotGeneral);

        add(panelTotales, BorderLayout.SOUTH);
        
        // Cargar reporte automáticamente al abrir
        SwingUtilities.invokeLater(() -> cargarReporte());
    }

  
// CARGAR REPORTE COMPLETO
private void cargarReporte() {
    modeloTabla.setRowCount(0);

    // Obtener fechas de los Spinners
    LocalDate desde = ((Date) spinnerFechaDesde.getValue()).toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    LocalDate hasta = ((Date) spinnerFechaHasta.getValue()).toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDate();

    // Validar rango de fechas
    if (hasta.isBefore(desde)) {
        JOptionPane.showMessageDialog(this, 
            "La fecha 'Hasta' no puede ser anterior a la fecha 'Desde'", 
            "Rango inválido", 
            JOptionPane.ERROR_MESSAGE);
        return;
    }

    double totalCuotas = 0;
    double totalEntradas = 0;
    double totalAbonos = 0;

    try {
       
        // CUOTAS PAGADAS 
   
        List<Cuota> cuotas = cuotaDAO.listar();
        for (Cuota c : cuotas) {
           
            if (c.isPagada()) {
                try {
                    // Convertir el periodo (YYYY-MM-DD) a LocalDate
                    LocalDate fechaCuota = LocalDate.parse(c.getPeriodo());
                    
                    if (!fechaCuota.isBefore(desde) && !fechaCuota.isAfter(hasta)) {
                        modeloTabla.addRow(new Object[]{
                            fechaCuota.toString(),
                            "Cuota Social",
                            c.getSocio().getNombre() + " " + c.getSocio().getApellido(),
                            String.format("$%.2f", c.getMonto())
                        });
                        totalCuotas += c.getMonto();
                    }
                } catch (Exception e) {
                    // Si hay error al parsear la fecha, saltar esta cuota
                    System.err.println("Error parseando fecha de cuota: " + c.getPeriodo());
                }
            }
        }

     
        // ENTRADAS 
      
        List<Entrada> entradas = entradaDAO.listar();
        for (Entrada e : entradas) {
            if (e.getFechaCompra() != null) {
                LocalDate fechaE = e.getFechaCompra().toLocalDate();
                
                if (!fechaE.isBefore(desde) && !fechaE.isAfter(hasta)) {
                    modeloTabla.addRow(new Object[]{
                        fechaE.toString(),
                        "Entrada " + e.getTipo(), // getTipo() existe en tu clase
                        e.getNombreComprador() != null ? e.getNombreComprador() : "Visitante",
                        String.format("$%.2f", e.getPrecio())
                    });
                    totalEntradas += e.getPrecio();
                }
            }
        }

       
        // ABONOS DE PILETA
    
        List<AbonoPileta> abonos = abonoDAO.listar();
        for (AbonoPileta a : abonos) {
            if ("Pagado".equalsIgnoreCase(a.getEstadoPago()) && a.getFechaInicio() != null) {
                LocalDate fechaA = a.getFechaInicio();
                
                if (!fechaA.isBefore(desde) && !fechaA.isAfter(hasta)) {
                    modeloTabla.addRow(new Object[]{
                        fechaA.toString(),
                        "Abono Pileta (" + a.getTipo() + ")",
                        a.getSocio().getNombre() + " " + a.getSocio().getApellido(),
                        String.format("$%.2f", a.getPrecio())
                    });
                    totalAbonos += a.getPrecio();
                }
            }
        }

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this,
            "Error al generar reporte: " + ex.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE);
    }

 
    // ACTUALIZAR TOTALES

    lblTotCuotas.setText(String.format("Total Cuotas: $%.2f", totalCuotas));
    lblTotEntradas.setText(String.format("Total Entradas: $%.2f", totalEntradas));
    lblTotAbonos.setText(String.format("Total Abonos: $%.2f", totalAbonos));

    double totalGeneral = totalCuotas + totalEntradas + totalAbonos;
    lblTotGeneral.setText(String.format("TOTAL GENERAL: $%.2f", totalGeneral));
    
    // Mostrar resumen
    JOptionPane.showMessageDialog(this,
        String.format("Reporte generado para %s a %s:\n- Cuotas: $%.2f\n- Entradas: $%.2f\n- Abonos: $%.2f\n- TOTAL: $%.2f", 
            desde, hasta, totalCuotas, totalEntradas, totalAbonos, totalGeneral),
        "Resumen del Reporte",
        JOptionPane.INFORMATION_MESSAGE);
}
}