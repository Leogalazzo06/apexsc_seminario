package apexsc;

import java.time.LocalDate;

public class Cuota {

    private int id;
    private String periodo;    // YYYY-MM-DD
    private double monto;
    private String estado;     // Pendiente / Pagada / Vencida
    private Socio socio;
    private boolean pagada;

    public Cuota() {}

    public Cuota(int id, String periodo, double monto, String estado, Socio socio, boolean pagada) {
        this.id = id;
        this.periodo = periodo;
       	this.monto = monto;
        this.estado = estado;
        this.socio = socio;
        this.pagada = pagada;
    }

    public Cuota(String periodo, double monto, String estado, Socio socio, boolean pagada) {
        this.periodo = periodo;
        this.monto = monto;
        this.estado = estado;
        this.socio = socio;
        this.pagada = pagada;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }

    public double getMonto() { return monto; }
    public void setMonto(double monto) { this.monto = monto; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public Socio getSocio() { return socio; }
    public void setSocio(Socio socio) { this.socio = socio; }

    public boolean isPagada() { return pagada; }
    public void setPagada(boolean pagada) { this.pagada = pagada; }

    // Helpers con LocalDate
    public LocalDate getFechaVencimiento() {
        return LocalDate.parse(periodo);
    }

    public void setFechaVencimiento(LocalDate fecha) {
        this.periodo = fecha.toString();
    }

    public boolean estaVencida() {
        if (pagada) return false;
        try {
            return getFechaVencimiento().isBefore(LocalDate.now());
        } catch (Exception e) {
            return false;
        }
    }
}
