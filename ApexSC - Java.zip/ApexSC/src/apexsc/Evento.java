package apexsc;

import java.time.LocalDate;

public class Evento {

    private int id;
    private String nombre;
    private LocalDate fecha;
    private int aforo;
    private int idUsuario;
    private String lugar;
    private double precioGeneral;
    private double precioSocio;
    private double precioInvitado;

    public Evento() {}

    // Constructor completo
    public Evento(int id, String nombre, LocalDate fecha, int aforo, String lugar,
                  double precioGeneral, double precioSocio, double precioInvitado, int idUsuario) {

        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
        this.aforo = aforo;
        this.lugar = lugar;
        this.precioGeneral = precioGeneral;
        this.precioSocio = precioSocio;
        this.precioInvitado = precioInvitado;
        this.idUsuario = idUsuario;
    }

    // Constructor sin ID
    public Evento(String nombre, LocalDate fecha, int aforo, String lugar,
                  double precioGeneral, double precioSocio, double precioInvitado, int idUsuario) {

        this.nombre = nombre;
        this.fecha = fecha;
        this.aforo = aforo;
        this.lugar = lugar;
        this.precioGeneral = precioGeneral;
        this.precioSocio = precioSocio;
        this.precioInvitado = precioInvitado;
        this.idUsuario = idUsuario;
    }

   
    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public int getAforo() { return aforo; }
    public void setAforo(int aforo) { this.aforo = aforo; }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }

    public String getLugar() { return lugar; }
    public void setLugar(String lugar) { this.lugar = lugar; }

    public double getPrecioGeneral() { return precioGeneral; }
    public void setPrecioGeneral(double precioGeneral) { this.precioGeneral = precioGeneral; }

    public double getPrecioSocio() { return precioSocio; }
    public void setPrecioSocio(double precioSocio) { this.precioSocio = precioSocio; }

    public double getPrecioInvitado() { return precioInvitado; }
    public void setPrecioInvitado(double precioInvitado) { this.precioInvitado = precioInvitado; }

    //Método para que se muestre correctamente
    @Override
    public String toString() {
        return nombre + " (" + fecha.toString() + ")";
    }

    // Obtener precio según tipo elegido
    public double obtenerPrecioPorTipo(String tipo) {
        switch (tipo) {
            case "General":
                return precioGeneral;
            case "Popular":
                return precioSocio;       
            case "Palco":
                return precioInvitado;   
            default:
                return precioGeneral;
        }
    }
}
