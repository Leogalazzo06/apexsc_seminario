package apexsc;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class VentanaMorosos extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;
    private JTextField txtBuscar;

    private CuotaDAO cuotaDAO;

    public VentanaMorosos() {

        cuotaDAO = new CuotaDAO();

        setTitle("Listado de Morosos");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new BorderLayout(10,10));

        Color azul = new Color(0, 51, 102);
        Color dorado = new Color(218,165,32);
        Color fondo = new Color(245,247,255);

        // BUSQUEDA
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT,10,10));
        top.setBackground(fondo);

        top.add(new JLabel("Buscar socio:"));
        txtBuscar = new JTextField(25);
        JButton btnBuscar = crearBoton("Buscar", azul, dorado);

        top.add(txtBuscar);
        top.add(btnBuscar);

        add(top, BorderLayout.NORTH);

        // TABLA
        modelo = new DefaultTableModel(
                new String[]{"Socio", "DNI", "Cuotas Adeudadas", "Total Deuda", "Último Período"},
                0
        ) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createTitledBorder("Socios Morosos"));

        add(scroll, BorderLayout.CENTER);

        // Evento buscar
        btnBuscar.addActionListener(e -> cargarMorosos());

        // Cargar al iniciar
        cargarMorosos();

        setVisible(true);
    }

    private JButton crearBoton(String texto, Color fondo, Color borde) {
        JButton b = new JButton(texto);
        b.setFocusPainted(false);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setBorder(BorderFactory.createLineBorder(borde, 2));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void cargarMorosos() {
        try {
            modelo.setRowCount(0);

            List<MorosoDTO> lista = cuotaDAO.listarMorosos(txtBuscar.getText().trim());

            for (MorosoDTO m : lista) {
                modelo.addRow(new Object[]{
                        m.getNombreCompleto(),
                        m.getDni(),
                        m.getCuotasPendientes(),
                        "$ " + m.getTotalDeuda(),
                        m.getUltimoPeriodo()
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando morosos:\n" + e.getMessage());
        }
    }
}
