package apexsc;

import javax.swing.*;
import java.awt.*;

public class VentanaLogin extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private UsuarioDAO usuarioDAO;

    public VentanaLogin() {

        usuarioDAO = new UsuarioDAO();

        setTitle("Inicio de Sesión - Apex SC");
        setExtendedState(JFrame.MAXIMIZED_BOTH); 
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Colores corporativos del sistema
        Color azulOscuro = new Color(0, 51, 102);
        Color azulMedio = new Color(0, 40, 80);
        Color dorado = new Color(218, 165, 32);
        Color fondo = new Color(248, 250, 255);

        // Panel principal con layout de cuadrícula para centrar
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        panelPrincipal.setBackground(fondo);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Panel del formulario
        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BoxLayout(panelFormulario, BoxLayout.Y_AXIS));
        panelFormulario.setBackground(fondo);
        panelFormulario.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));
        panelFormulario.setMaximumSize(new Dimension(450, 600)); // Tamaño máximo fijo

        // LOGO 
        JPanel panelLogo = new JPanel();
        panelLogo.setBackground(fondo);
        panelLogo.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelLogo.setMaximumSize(new Dimension(300, 150));

        try {
            ImageIcon iconLogo = new ImageIcon(getClass().getResource("/apexsc/logo.png"));
            Image imgLogo = iconLogo.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
            JLabel lblLogo = new JLabel(new ImageIcon(imgLogo));
            lblLogo.setHorizontalAlignment(JLabel.CENTER);
            panelLogo.add(lblLogo);
        } catch (Exception ex) {
            JLabel lblTituloLogo = new JLabel("APEX SC", JLabel.CENTER);
            lblTituloLogo.setFont(new Font("Segoe UI", Font.BOLD, 36));
            lblTituloLogo.setForeground(azulOscuro);
            panelLogo.add(lblTituloLogo);
        }

        //TÍTULO Y SUBTÍTULO 
        JLabel lblTitulo = new JLabel("Iniciar sesión", JLabel.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitulo.setForeground(azulOscuro);
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));

        JLabel lblSubtitulo = new JLabel("Sistema de Gestión Integral", JLabel.CENTER);
        lblSubtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblSubtitulo.setForeground(new Color(100, 100, 120));
        lblSubtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblSubtitulo.setBorder(BorderFactory.createEmptyBorder(0, 0, 40, 0));

        //CAMPOS DEL FORMULARIO 
        // Panel para usuario
        JPanel panelUsuario = new JPanel(new BorderLayout(0, 8));
        panelUsuario.setBackground(fondo);
        panelUsuario.setMaximumSize(new Dimension(400, 80));
        
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblUsuario.setForeground(azulOscuro);
        
        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        txtUsuario.setBackground(Color.WHITE);
        txtUsuario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 225), 1),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        txtUsuario.setCaretColor(azulMedio);
        
        panelUsuario.add(lblUsuario, BorderLayout.NORTH);
        panelUsuario.add(txtUsuario, BorderLayout.CENTER);

        // Espaciador
        Component espaciador1 = Box.createVerticalStrut(25);

        // Panel para contraseña
        JPanel panelPassword = new JPanel(new BorderLayout(0, 8));
        panelPassword.setBackground(fondo);
        panelPassword.setMaximumSize(new Dimension(400, 80));
        
        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblPassword.setForeground(azulOscuro);
        
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        txtPassword.setBackground(Color.WHITE);
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 225), 1),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        txtPassword.setCaretColor(azulMedio);
        
        panelPassword.add(lblPassword, BorderLayout.NORTH);
        panelPassword.add(txtPassword, BorderLayout.CENTER);

        // Espaciador
        Component espaciador2 = Box.createVerticalStrut(35);

        // BOTÓN 
        JButton btnLogin = new JButton("Ingresar");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnLogin.setBackground(azulMedio);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.setFocusPainted(false);
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.setMaximumSize(new Dimension(300, 50));
        btnLogin.setBorder(BorderFactory.createEmptyBorder(12, 40, 12, 40));

        // Efectos hover
        btnLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLogin.setBackground(dorado);
                btnLogin.setForeground(Color.BLACK);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLogin.setBackground(azulMedio);
                btnLogin.setForeground(Color.WHITE);
            }
        });

        btnLogin.addActionListener(e -> realizarLogin());

        // VERSIÓN
        JLabel lblVersion = new JLabel("Versión 1.2 - Desarrollado por Leonel Agustín Galazzo", JLabel.CENTER);
        lblVersion.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblVersion.setForeground(new Color(120, 120, 140));
        lblVersion.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblVersion.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 0));

        // ENSAMBLAR FORMULARIO 
        panelFormulario.add(panelLogo);
        panelFormulario.add(lblTitulo);
        panelFormulario.add(lblSubtitulo);
        panelFormulario.add(panelUsuario);
        panelFormulario.add(espaciador1);
        panelFormulario.add(panelPassword);
        panelFormulario.add(espaciador2);
        panelFormulario.add(btnLogin);
        panelFormulario.add(lblVersion);

        // AGREGAR AL PANEL PRINCIPAL
        panelPrincipal.add(panelFormulario);
        add(panelPrincipal);

        // CONFIGURACIONES FINALES 
        getRootPane().setDefaultButton(btnLogin);
        
        // Focus inicial
        SwingUtilities.invokeLater(() -> txtUsuario.requestFocusInWindow());
        
        setVisible(true);
    }

    //LOGIN 
    private void realizarLogin() {
        try {
            String user = txtUsuario.getText().trim();
            String pass = new String(txtPassword.getPassword());

            if (user.isEmpty() || pass.isEmpty()) {
                mostrarError("Por favor, complete todos los campos.", "Campos incompletos");
                return;
            }

            Usuario u = usuarioDAO.buscarPorUsernameYPassword(user, pass);

            if (u == null) {
                mostrarError("Usuario o contraseña incorrectos.", "Error de autenticación");
                return;
            }

            Sesion.setUsuarioActual(u);

            JOptionPane.showMessageDialog(this,
                    "<html><div style='text-align: center;'>"
                    + "<b>¡Bienvenido/a, " + u.getUsername() + "!</b><br>"
                    + "Rol: " + u.getRol()
                    + "</div></html>",
                    "Login exitoso",
                    JOptionPane.INFORMATION_MESSAGE);

            dispose();
            new ApexSC(u).setVisible(true);

        } catch (Exception e) {
            mostrarError("Error al conectar con la base de datos:\n" + e.getMessage(), "Error del sistema");
        }
    }

    private void mostrarError(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(this,
                "<html><div style='text-align: center;'>" + mensaje + "</div></html>",
                titulo,
                JOptionPane.ERROR_MESSAGE);
    }
}