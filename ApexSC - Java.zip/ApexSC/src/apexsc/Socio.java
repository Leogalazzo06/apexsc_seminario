package apexsc;

public class Socio {

    private int id;
    private String nombre;
    private String apellido;
    private String dni;
    private String estado;
    private int idUsuarioCreador;
    private String categoria;
    private String periodicidad;
    private String fotoRuta;

    public Socio() {}

    // Constructor para BD
    public Socio(int id, String nombre, String apellido, String dni, String estado, int idUsuarioCreador) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.estado = estado;
        this.idUsuarioCreador = idUsuarioCreador;
    }

    // Constructor para insertar
    public Socio(String nombre, String apellido, String dni, String estado, int idUsuarioCreador) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.estado = estado;
        this.idUsuarioCreador = idUsuarioCreador;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public int getIdUsuarioCreador() { return idUsuarioCreador; }
    public void setIdUsuarioCreador(int idUsuarioCreador) { this.idUsuarioCreador = idUsuarioCreador; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public String getPeriodicidad() { return periodicidad; }
    public void setPeriodicidad(String periodicidad) { this.periodicidad = periodicidad; }

    // GET/SET DE FOTO
    public String getFotoRuta() { return fotoRuta; }
    public void setFotoRuta(String fotoRuta) { this.fotoRuta = fotoRuta; }

    @Override
    public String toString() {
        return nombre + " " + apellido + " - " + categoria + " (DNI: " + dni + ")";
    }
}
