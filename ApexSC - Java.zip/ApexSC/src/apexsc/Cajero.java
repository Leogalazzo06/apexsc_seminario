package apexsc;

public class Cajero extends Usuario {

    public Cajero(String usuario, String contrasena) {
        super(usuario, contrasena, "Cajero");
    }

    public void mostrarMenu() {
        System.out.println("\n--- Menú del Cajero ---");
        System.out.println("1. Cobrar Cuotas");
        System.out.println("2. Emitir Recibos");
        System.out.println("3. Consultar Pagos");
    }
}
